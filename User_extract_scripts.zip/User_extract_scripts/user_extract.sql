set pages 0 lines 300
col OPEN_MODE for a10
col HOST_NAME for a30
set linesize 150
set pagesize 500
col grantee for a25
col grantor for a20
col privilege for a30
col OWNER for a15
col username for a25
col ACCOUNT_STATUS for a30
set lines 200 pages 0
set feedback off

select NAME,a.GRANTEE,b.USER_ID,b.username,b.account_status,a.GRANTED_ROLE,a.ADMIN_OPTION,a.DEFAULT_ROLE
from DBA_ROLE_PRIVS a,dba_users b,v$database
where a.GRANTEE=b.username order by GRANTEE,GRANTED_ROLE;
