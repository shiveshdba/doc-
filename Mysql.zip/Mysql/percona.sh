#!/bin/bash
########################################################################
help="
  Name:    percona.sh              

  Purpose: Take Full Backup of mysql instance and prepare with Binlogs
         
"
# 
# ----------------------------------------------------------------------
# REVISION HISTORY       ** PLEASE KEEP MOST RECENT FIRST **
#
# REV    DATE     BY               DESCRIPTION
# --- ---------- -------------    -----------
# 000	21-Aug-19 Shivesh Mishra  Initial Release
########################################################################
#
#
#----------------------------------------------------------------------
# Check for options
#----------------------------------------------------------------------
#
backupdir=/u01/percona_bkp
logfile=/u01/log/backup_`date +%Y%m%d`.log


percona_fullbkp ()
{
# Taking Full backup
exec &> $logfile
 
echo "------------ Starting Full backup---------------------------"
innobackupex --defaults-file=/opt/rh/mysql55/root/etc/my.cnf --user bekupuser --password=Tesco@2019 --socket=/var/lib/mysql/mysql.sock --port=3306 --datadir=/u02/mysql/data /u01/percona_bkp 

echo "--------------- End of full backup-----------------------------"


# Prepare Full backup with Binlong

currentbkp=`ls -ltr $backupdir | tail -1 | awk {'print $9'}`

echo "--------------- Full Backup Taken directory-----------------------------"

echo $currentbkp

#exec &>> $logfile

echo "----------------- Starting Prepare Backup-----------------------"

innobackupex --defaults-file=/opt/rh/mysql55/root/etc/my.cnf --user bekupuser --password=Tesco@2019 --socket=/var/lib/mysql/mysql.sock --port=3306 --datadir=/u02/mysql/data --apply-log /u01/percona_bkp/$currentbkp

echo "------------------End of Prepare Backup------------------------"

#exec &>> $logfile
echo "------------------Listing Full backup Taken------------------------"

# Listing Full Backp

cd /u01/percona_bkp/$currenbkp

ls -ltr

# Deleting Old backups and logs

echo "------- Listing &  deleting deleting old backups---------------------"

find /u01/percona_bkp/  -ctime +7 -print -exec rm -rf {} +

echo "--------------------Deleting Logs----------------------------"

/usr/bin/find /u01/log -name \*.log -mtime +7 -exec rm {} \;

}

# Calls
percona_fullbkp







