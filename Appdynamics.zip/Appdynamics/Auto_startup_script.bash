#This script checks if appd is running and attempts startup if it doesn't"
#!/bin/bash
procs=`ps -ef|grep -i appd|egrep '/moni|saas'|wc -l`
if [ "$procs" -eq 2 ]
then
echo "all fine"
elif [ "$procs" -eq 1 ]
then
echo "May be the Appd custom scripts are not initiated. Please check" | mail -s "Looks like all APPD processes are not running on `hostname` " HSC_Asia_Oracle_DBA@tesco.com
elif [ "$procs" -eq 0 ]
then
echo "Could not find APPD processes. Attempting start" |  mail -s "Critical: APPD processes are not running on `hostname` " HSC_Asia_Oracle_DBA@tesco.com
/bin/sh /u01/oracle/AppDynamics/start_appd.sh 1>/dev/null 2>/dev/null &
fi;

########## Appd Moniotoing#################
00,15,30,45 * * * * /u01/oracle/AppDynamics/appd_monitor.sh 1>/dev/null 2>/dev/null &

for pid in $(ps -ef | grep -i appd|egrep '/moni|saas' | awk {'print $2'}); do kill -9 $pid; done 

