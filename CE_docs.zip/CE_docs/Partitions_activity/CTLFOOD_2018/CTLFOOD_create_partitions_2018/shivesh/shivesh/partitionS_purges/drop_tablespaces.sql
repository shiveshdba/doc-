!date
set time on
set echo on
set feedback on
spool Drop_tablespaces.log

drop tablespace  CTLFOOD_201511 including contents and datafiles;
drop tablespace  CTLFOOD_201512 including contents and datafiles;
drop tablespace  CTLFOOD_201601 including contents and datafiles;
drop tablespace  CTLFOOD_201602 including contents and datafiles;
drop tablespace  CTLFOOD_201603 including contents and datafiles;
drop tablespace  CTLFOOD_201604 including contents and datafiles;
drop tablespace  CTLFOOD_201605 including contents and datafiles;
drop tablespace  CTLFOOD_201606 including contents and datafiles;
drop tablespace  CTLFOOD_201607 including contents and datafiles;
drop tablespace  CTLFOOD_201608 including contents and datafiles;
drop tablespace  CTLFOOD_201609 including contents and datafiles;
drop tablespace  CTLFOOD_201610 including contents and datafiles;
!date
spool off;
