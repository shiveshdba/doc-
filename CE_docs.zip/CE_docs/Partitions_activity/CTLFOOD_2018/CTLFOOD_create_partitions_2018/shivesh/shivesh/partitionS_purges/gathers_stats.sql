!date
set time on
set echo on
set feedback on
spool Tables_gathers_stats.log

execute dbms_stats.gather_table_stats(ownname=>'CTLFOOD', tabname=>'CARD_MOVEMENT_DAILY', estimate_percent=>33, cascade=>true , granularity => 'ALL', degree => 8);
execute dbms_stats.gather_table_stats(ownname=>'CTLFOOD', tabname=>'DAILY_CARD', estimate_percent=>33, cascade=>true , granularity => 'ALL', degree => 8);
execute dbms_stats.gather_table_stats(ownname=>'CTLFOOD', tabname=>'SUM_CLUBCARD_CARD', estimate_percent=>33, cascade=>true , granularity => 'ALL', degree => 8);
execute dbms_stats.gather_table_stats(ownname=>'CTLFOOD', tabname=>'DAILY_FOOD', estimate_percent=>33, cascade=>true , granularity => 'ALL', degree => 8);
execute dbms_stats.gather_table_stats(ownname=>'CTLFOOD', tabname=>'SUM_HOURLY', estimate_percent=>33, cascade=>true , granularity => 'ALL', degree => 8);
execute dbms_stats.gather_table_stats(ownname=>'CTLFOOD', tabname=>'DAILY_ITEM', estimate_percent=>33, cascade=>true , granularity => 'ALL', degree => 8);
!date
spool off;


