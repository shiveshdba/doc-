!date
set time on
set echo on
set feedback on
spool index_rebuild.log

alter index CTLFOOD.CARD_MV_DAILY_IDX_01 rebuild online parallel 8 nologging;
alter index CTLFOOD.CARD_MV_DAILY_IDX_01 noparallel logging;
alter index CTLFOOD.CARDMOVEMENTDAILY_IDX_1 rebuild online parallel 8 nologging;
alter index CTLFOOD.CARDMOVEMENTDAILY_IDX_1 noparallel logging;
alter index CTLFOOD.CARDMOVEMENTDAILY_IDX_2 rebuild online parallel 8 nologging;
alter index CTLFOOD.CARDMOVEMENTDAILY_IDX_2 noparallel logging;
alter index CTLFOOD.CARDMOVEMENTDAILY_IDX_3 rebuild online parallel 8 nologging;
alter index CTLFOOD.CARDMOVEMENTDAILY_IDX_3 noparallel logging;

alter index CTLFOOD.DAILY_CARD_IDX_01 rebuild online parallel 8 nologging;
alter index CTLFOOD.DAILY_CARD_IDX_01 noparallel logging;

alter index CTLFOOD.SUM_CLUBCARD_CARD_PK rebuild online parallel 8 nologging;
alter index CTLFOOD.SUM_CLUBCARD_CARD_PK noparallel logging;

alter index CTLFOOD.DAILY_FOOD_IDX_01 rebuild online parallel 8 nologging;
alter index CTLFOOD.DAILY_FOOD_IDX_01 noparallel logging; 

alter index CTLFOOD.SUMHOURLY_IDX_3 rebuild online parallel 8 nologging;
alter index CTLFOOD.SUMHOURLY_IDX_2 rebuild online parallel 8 nologging;
alter index CTLFOOD.SUMHOUR_IDX_01  rebuild online parallel 8 nologging;
alter index CTLFOOD.SUMHOURLY_IDX_1 rebuild online parallel 8 nologging;

alter index CTLFOOD.SUMHOURLY_IDX_3 noparallel logging;
alter index CTLFOOD.SUMHOURLY_IDX_2 noparallel logging;
alter index CTLFOOD.SUMHOUR_IDX_01  noparallel logging;
alter index CTLFOOD.SUMHOURLY_IDX_1 noparallel logging;

alter index CTLFOOD.DAILY_ITEM_IDX_01 rebuild online parallel 8 nologging;
alter index CTLFOOD.DAILY_ITEM_IDX_01 noparallel logging;
!date
spool off;

