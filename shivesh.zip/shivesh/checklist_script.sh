#!/bin/bash
########################################################################
help="
  Name:    checklist_script.sh
BOBOBOBOB               

  Purpose: For each instance listed in the ORATAB file, try to login;
           if successful, Do All necessary health checkup and send report
	   to DB Team . 
          

  Usage:  checklist_script.sh 
"
# 
#
#
#         
#        
#
# ----------------------------------------------------------------------
# REVISION HISTORY       ** PLEASE KEEP MOST RECENT FIRST **
#
# REV    DATE     BY               DESCRIPTION
# --- ---------- -------------    -----------
# 000	25-Jan-17 Shivesh Mishra  Initial Release
########################################################################
#
#
#----------------------------------------------------------------------
# Check for options
#----------------------------------------------------------------------
#
echo "----------------------------------------------------------------"
. /home/oracle/.bash_profile
ORACLE_BASE=/vol01/app/oracle
export ORACLE_BASE 
ORATAB=/etc/oratab
export ORATAB
#grep "^[^#*][^:]*:[^:][^:]*:[YyNn]" $ORATAB | cut -d : -f 1 | tee /home/oracle/shivesh/tns_db.par
exec 1>/home/oracle/shivesh/check_`date +%Y%m%d`.html
cd /home/oracle
a=0
while read line
do
if [ -n "$line" ] ; then
        #echo $line
        TNS=`echo $line`
echo "DB Name: "$TNS
VAR1=`echo $line | cut -d',' -f1`

ORACLE_SID=$VAR1
VAR2=`echo $line | cut -d',' -f2`
echo $VAR1
echo $VAR2
if [ "$VAR2" -eq 1 ];
then
ORACLE_BASE=/vol01/app/oracle
ORACLE_HOME=/vol01/app/oracle/product/db/12.2.0.1
#ORACLE_SID=DEAL
export ORACLE_BASE ORACLE_HOME
NLS_LANG=_.WE8ISO8859P1
LD_LIBRARY_PATH=$ORACLE_HOME/lib:$LD_LIBRARY_PATH
PATH=$ORACLE_HOME/bin:$PATH
export NLS_LANG LD_LIBRARY_PATH PATH
ORATAB=/etc/oratab
export ORATAB
TNS_ADMIN=$ORACLE_HOME/network/admin
export TNS_ADMIN
export ORACLE_SID
else
ORACLE_BASE=/vol01/app/oracle
ORACLE_HOME=/vol01/app/oracle/product/db/12.1.0.2
#ORACLE_SID=DEAL
export ORACLE_BASE ORACLE_HOME
NLS_LANG=_.WE8ISO8859P1
LD_LIBRARY_PATH=$ORACLE_HOME/lib:$LD_LIBRARY_PATH
PATH=$ORACLE_HOME/bin:$PATH
export NLS_LANG LD_LIBRARY_PATH PATH
ORATAB=/etc/oratab
export ORATAB
TNS_ADMIN=$ORACLE_HOME/network/admin
export TNS_ADMIN
export ORACLE_SID 
fi
sqlplus -s /nolog <<SQLCONN
connect / as sysdba
spool /home/oracle/shivesh/daily_checklist.log
@/home/oracle/shivesh/checklist.sql;
SQLCONN

fi
a=`expr $a + 1`
echo "========================================================================"
echo "=====DB $a completed for $line=============================="
echo "======================================================================="
done < /home/oracle/shivesh/tns_db.par
#
#
#echo "Check attached report and review it." | mutt -a "/home/oracle/scripts/check_`date +%Y%m%d`.html" -s "Health checkup of DB MOUNTED ON NJ4-GEN-PORC4 Completed" \
# -c LEjjaki@us.univision.com -c crahner@UNIVISION.NET -c aiaz.muzzammill@capgemini.com ETSDBSOracleServerSupport@univision.net
echo "Check attached report and review it." | mailx -s "Health checkup of DB MOUNTED ON NJ4-GEN-PORC6 Completed" -a "/home/oracle/shivesh/check_`date +%Y%m%d`.html" \
 -c LEjjaki@us.univision.com -c crahner@UNIVISION.NET -c aiaz.muzzammill@capgemini.com ETSDBSOracleServerSupport@univision.net
#
#
# Delete old logfiles
/usr/bin/find /home/oracle/shivesh -name \*.html -mtime +1 -exec rm {} \;
  
