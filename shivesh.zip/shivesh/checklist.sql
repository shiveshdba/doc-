spool /home/oracle/shivesh/health_checkup.html
SET MARKUP HTML ON
set heading off
SET TIME OFF
SET TIMING OFF
SET ECHO OFF
SET FEEDBACK OFF
SET LINESIZE 500
SET PAGESIZE 20000

--PROMPT 'ENTER YOU NAME'
--ACCEPT NM

alter session set nls_date_format = 'dd-mm-yyyy hh:mi'
/
--SELECT '*************STATISTICS COLLECTED BY '|| '&NM' ||'*****************' FROM DUAL
--/
select 'database statistics collected as on -- '|| sysdate || ' FOR '|| INSTANCE_NAME||' STARTED SINCE '|| STARTUP_TIME from V$INSTANCE
/
select 'DBID for database -- '||dbid from v$database
/
select 'Database Installed on Host -- '||UTL_INADDR.get_host_name from dual
/
SELECT 'Database Installed on Host with IP Address -- '||UTL_INADDR.get_host_address from dual
/
TTITLE LEFT '*********************** SIZE OF THE DATABASE*****************************'
SELECT 'Size in GB -- '||substr(to_char(sum(bytes)/1024/1024/1024, '999,999.99'), 1, 11) "GB"
from  dba_data_files
/
TTITLE OFF
TTITLE LEFT '*********************** SGA *****************************'
SHOW SGA
TTITLE OFF
SET HEADING ON
col FREE_SPACE     Heading 'FREE SPACE(MB)'
col USED_SPACE     Heading 'USED SPACE(MB)'
TTITLE LEFT '*********************** SHARED POOL SIZE***********************'
SELECT FREE_SPACE/1024/1024 "FREE SPACE(MB)" ,USED_SPACE/1024/1024 "USED SPACE(MB)" 
FROM V$SHARED_POOL_RESERVED
/
TTITLE OFF
SET HEADING OFF
SELECT 'DATABASE WORKING IN '|| LOG_MODE FROM V$DATABASE
/
select 'TOTAL CONCURRENT USERS LOGGED ON PRESENTLY --  '||sessions_current||' MAX. USERS LOGGED TODAY   --  '||sessions_highwater from v$license
/
select 'BUFFER CACHE HIT RATIO -- '|| ROUND((1 - (sum(decode(name,'physical reads',value,0) )/(sum(decode(name,'consistent gets',value,0))+sum(decode(name,'db block gets',value,0)))) )*100,2) HIT_RATIO
from v$sysstat
where name in ('physical reads','consistent gets','db block gets')
/
 select 'TOTAL NO OF DB BUFFERS OF BLOCK SIZE '||SUM(DECODE(NAME,'db_block_size',value,0))||'  :  '||SUM(DECODE(NAME,'db_block_buffers',value,0)) from v$parameter
 
/
SET HEADING ON
column object_name format a25
column owner format a10
column status format a7
column object_type format a18
col OBJECT_TYPE     Heading 'OBJECT TYPE'
col OWNER           Heading 'OWNER'
col OBJECT_NAME     Heading 'OBJECT NAME'
col STATUS          Heading 'STATUS'
TTITLE LEFT '*******************TOTAL OBJECTS**************************'
select object_type,count(*) from dba_objects
where status='VALID'
group by object_type
/
set heading off
TTITLE OFF
set heading on
column object_name format a25
column owner format a10
column status format a7
column object_type format a11
col OBJECT_TYPE     Heading 'OBJECT TYPE'
col OWNER           Heading 'OWNER'
col OBJECT_NAME     Heading 'OBJECT NAME'
col STATUS          Heading 'STATUS'
TTITLE LEFT '*******************VALID OBJECTS IN THE DATABASE**************************'
SELECT count(*) ,OBJECT_TYPE "OBJECT TYPE",OWNER "OWNER",STATUS "STATUS"
 FROM DBA_OBJECTS WHERE STATUS='VALID' AND OWNER NOT IN ('SYS','SYSTEM','PUBLIC','OUTLN','WMSYS','ORDSYS','ORDPLUGINS','MDSYS','CTXSYS','XDB',
'WKSYS','ODM','ODM_MTR','OLAPSYS','RMAN','HR','OE','PM','SH','QS_ADM','QS','QS_WS','QS_ES','QS_OS','QS_CBADM','QS_CS','AURORA$JIS$UTILITY$','OSE$HTTP$ADMIN')
group by OBJECT_TYPE,OWNER,STATUS
/
set heading off
TTITLE OFF
SELECT 'TOTAL VALID OBJECTS COUNT IN THE DATABASE IS -- '|| COUNT(*) FROM DBA_OBJECTS WHERE STATUS='VALID'
/
set heading on
column object_name format a25
column owner format a10
column status format a7
column object_type format a11
col OBJECT_TYPE     Heading 'OBJECT TYPE'
col OWNER           Heading 'OWNER'
col OBJECT_NAME     Heading 'OBJECT NAME'
col STATUS          Heading 'STATUS'
TTITLE LEFT '*******************INVALID OBJECTS IN THE DATABASE**************************'
SELECT count(*) ,OBJECT_TYPE "OBJECT TYPE",OWNER "OWNER",STATUS "STATUS"
FROM DBA_OBJECTS WHERE STATUS='INVALID' AND OWNER NOT IN ('SYS','SYSTEM','PUBLIC','OUTLN','WMSYS','ORDSYS','ORDPLUGINS','MDSYS','CTXSYS','XDB',
'WKSYS','ODM','ODM_MTR','OLAPSYS','RMAN','HR','OE','PM','SH','QS_ADM','QS','QS_WS','QS_ES','QS_OS','QS_CBADM','QS_CS')
group by OBJECT_TYPE,OWNER,STATUS
/

TTITLE OFF
set heading off
SELECT 'TOTAL INVALID OBJECTS COUNT IN THE DATABASE IS -- '|| COUNT(*) FROM DBA_OBJECTS WHERE STATUS='INVALID'
/
set heading off
ttitle skip 1 left '*******************LIBRARY CACHE HITRATIO STATISTICS ******************'
SELECT NAMESPACE,GETHITRATIO FROM V$LIBRARYCACHE
/
TTITLE OFF


--select 'FREE DB BUFFERS :  '||COUNT(STATUS) FROM V$BH WHERE STATUS='free'
/
SELECT 'SQL AREA HIT RATIO  -- '||ROUND((1 - SUM(RELOADS)/(SUM(PINS)+ SUM(RELOADS)))*100,2) FROM V$LIBRARYCACHE
/
SELECT 'DD CACHE HIT RATIO -- '|| ROUND((1 - SUM(GETMISSES)/(SUM(GETS) + Sum(getmisses)))*100,2) FROM V$ROWCACHE
/
SELECT 'LATCH HIT RATIO -- ' || ROUND((1 - (Sum(misses) / Sum(gets))) * 100,2) 
  FROM   v$latch
/
--SELECT 'FREE SHARED POOL MEMORY -- '||BYTES FROM V$SGASTAT WHERE POOL = 'shared pool' AND NAME= 'free memory'
/
SELECT 'PRESENT SORT_AREA_SIZE --         '||VALUE FROM V$parameter WHERE NAME IN ('sort_area_size')
/
select 'TOTAL SORTS ON THE DATABASE --    MEMORY:  '||sum(decode(name,'sorts (memory)',value,0))||'       DISK:  '||sum(decode(name,'sorts (disk)',value,0))||'    DISK SORTS% :  '||
round(sum(decode(name,'sorts (disk)',value,0))/sum(decode(name,'sorts (memory)',value,0)),2)
from v$sysstat
/
column value format 99999999
ttitle skip 1 left '*******************DBWR CUM BUFFER CACHE STATISTICS ******************' skip 2 
select name,value from v$sysstat where name in 
('DBWR make free requests','DBWR buffers scanned','DBWR checkpoints',
'free buffer requested','dirty buffers inspected','free buffer inspected')
union
select event, total_waits from v$system_event
where event in ('buffer busy waits')
/

TTITLE OFF
SET HEADING ON

SELECT P1 "FILE#",P2 "BLOCK#",P3 "REASON",OWNER,SEGMENT_NAME,SEGMENT_TYPE
FROM DBA_EXTENTS,V$SESSION_WAIT
WHERE P1=FILE_ID
AND P2 BETWEEN BLOCK_ID AND BLOCK_ID+BLOCKS-1
AND EVENT='buffer busy waits'
/

column event format a25



TTITLE LEFT '************************** BUFFER BUSY WAITS **************************'
SELECT * FROM V$WAITSTAT WHERE COUNT>0
/
TTITLE OFF

TTITLE LEFT '************************** SYSTEM EVENTS **************************'
SELECT * FROM V$SYSTEM_EVENT WHERE TIME_WAITED > 10000 ORDER BY TIME_WAITED DESC
/
TTITLE OFF

TTITLE LEFT '************************** SYSTEM EVENTS BY SID **************************'
SELECT * FROM V$SESSION_EVENT WHERE TIME_WAITED > 10000 ORDER BY TIME_WAITED DESC
/
TTITLE OFF
--SET HEADING OFF
TTITLE LEFT '************************** LIST OF SCHEMA IN DATABASE**************************'
SELECT USERNAME "SCHEMA NAME", DEFAULT_TABLESPACE "DEFAULT TABLESPACE",TEMPORARY_TABLESPACE "TEMPORARY TABLESPACE"
FROM DBA_USERS ORDER BY 1
/
TTITLE OFF

TTITLE LEFT '************************** TABLESPACE BASIC INFORMATION **************************'
col Tablespace_name Heading 'Tablespace'
col Megs_Alloc      Heading 'Megs Alloc'
col Megs_Free       Heading 'Megs Free'
col Megs_Used       Heading 'Megs Used'
col file_name	    Heading 'Datafile'
col file_name format a45
select c.tablespace_name,
       b.file_name,
       round(a.bytes/1048576) Megs_Alloc,
       round(b.bytes/1048576) Megs_Free,
       round((a.bytes-b.bytes)/1048576) Megs_Used
from 
	(select tablespace_name,sum(a.bytes) bytes,
             	min(a.bytes) minbytes,max(a.bytes) maxbytes
    	 from 	sys.dba_data_files a
      	group by tablespace_name) a,
      (select a.tablespace_name,a.file_name,nvl(sum(b.bytes),0) bytes
     	 from sys.dba_data_files a,sys.dba_free_space b
      	where a.tablespace_name = b.tablespace_name (+)
        and    a.file_id = b.file_id (+)
        group by a.tablespace_name,a.file_name) b,
        sys.dba_tablespaces c
       where a.tablespace_name = b.tablespace_name(+)
       and a.tablespace_name = c.tablespace_name
       order by c.tablespace_name
/
TTITLE OFF
TTITLE LEFT '************************** TABLESPACE(TEMPORARY) BASIC INFORMATION **************************' skip 2
select TABLESPACE_NAME ,file_name from DBA_TEMP_FILES
/
TTITLE OFF
TTITLE LEFT '******************** TABLESPACE(TEMPORARY) SIZE INFORMATION**********************************'
select TABLESPACE_NAME ,(bytes_used+bytes_free)/1024/1024 "TOTAL SPACE" ,BYTES_USED/1024/1024 "USED SPACE", BYTES_FREE/1024/1024 "FREE SPACE" from V$TEMP_SPACE_HEADER
/
TTITLE OFF
SET HEADING OFF
column tablespace_name format a20
column file_name format a25
set heading on
ttitle skip 1 LEFT '-----------LIST OF TABLESPACES WHOSE FREE SPACE IS LESS THAN 25% OF ALLOCATED-------------' skip 2

select a.tablespace_name, file_name, sum(b.bytes) allocated,  sum(a.bytes)  free, autoextensible
from dba_free_space a, dba_data_files b
where a.file_id = b.file_id
group by a.tablespace_name, file_name, autoextensible
having sum(a.bytes) <  0.25*(sum(b.bytes)) -- free space less than 25%
/
TTITLE OFF
SET HEADING on

ttitle skip 1 LEFT '-----------LIST OF TABLESPACES AUTOMATICALLY COALESCED -------------' skip 2
SELECT TABLESPACE_NAME,PERCENT_BLOCKS_COALESCED FROM DBA_FREE_SPACE_COALESCED
WHERE PERCENT_BLOCKS_COALESCED < 100

/


TTITLE skip 1 LEFT "*************LIST OF TABLES WHERE ROW CHAINING HAS BEEN OBSERVED*************" skip 2 
 select owner,tablespace_name,table_name,avg_row_len,chain_cnt from dba_tables
 where chain_cnt >= 1
 order by tablespace_name,owner,table_name
/
ttitle off


TTITLE skip 1 LEFT "*************LIST OF NON-SYS USERS WHOSE OBJECTS ARE LYING IN SYSTEM*************" skip 2 
 select owner,round(sum(bytes)/(1024*1024),2) SZ,count(*) from dba_segments
 where tablespace_name = 'SYSTEM' and owner not in ('SYS','SYSTEM')
 GROUP BY OWNER
/
ttitle off
TTITLE skip 1 LEFT "*************LIST OF NON-SYS USERS WHOSE TEMPORARY TABLESPACES ARE INCORRECTLY SPECIFIED *************" skip 2 
  select username,temporary_tablespace, contents
 from dba_tablespaces a , dba_users b
 where username not in ('SYS','SYSTEM') and
 (temporary_tablespace = 'SYSTEM' or a.contents='PERMANENT')
 and a.tablespace_name=b.temporary_tablespace
/

ttitle off
TTITLE skip 1 CENTER 'REDO LOG STATISTICS' SKIP 2 LEFT "*************LIST OF REDO LOG GROUPS ******************"
SELECT GROUP#,THREAD#,SEQUENCE#,BYTES,MEMBERS,STATUS FROM V$LOG
/
TTITLE OFF
set heading off
 select 'LOG CHECKPOINT INTERVAL :  '||value from v$parameter where name like 'log_checkpoint_interval'
/
alter session set nls_date_format='dd-mm-yyyy hh24:mi'
/
set heading on
TTITLE skip 1 LEFT "*************REDO LOG SWITCH STATISTICS ******************" skip 2 
-- select max(b.sequence#),
--round(avg((b.first_time - a.first_time)*24*60),2) avg_switch_time_mins,
-- round(max((b.first_time - a.first_time)*24*60),2) max_switch_time_mins,
--round(min((b.first_time - a.first_time)*24*60),2) min_switch_time_mins
-- from v$loghist a, v$loghist b
--where b.sequence# = a.sequence#+1
--and b.first_time between (to_date(sysdate) - 3) and sysdate
/
TTITLE OFF
set heading off
 select 'SIZE OF LOG BUFFER  :  '||value from v$parameter where name like 'log_buffer'
/
TTITLE skip 1 LEFT "*************REDO LOG WAIT STATISTICS *******************" skip 2 
set heading on
select sum(decode(name,'redo entries',value,0)) redo_entries,
sum(decode(name,'redo buffer allocation retries',value,0)) redo_buffer_alloc_retries,
 sum(decode(name,'redo log space requests',value,0)) redo_log_space_req,
sum(decode(name,'redo log space wait time',value,0)) redo_log_space_wait_time
from v$sysstat
/
ttitle off

TTITLE skip 1 LEFT "************* ROLLBACK STATEMENTS STATISTICS *************" skip 2 
SELECT NAME,EXTENTS,ROUND(RSSIZE/(1024*1024),2) "SIZE(MB)",ROUND(OPTSIZE/(1024*1024),2) "OPTSIZE (MB)" ,WAITS,WRITES,XACTS,SHRINKS,WRAPS,EXTENDS
FROM V$ROLLSTAT A, V$ROLLNAME B
 WHERE A.USN = B.USN
/
TTITLE OFF
TTITLE skip 1 LEFT "************* UNDO WAIT STATISTICS *************************"
select class,count from v$waitstat
where class in ('system undo header','system undo block','undo header','undo block')
/
TTITLE OFF
column name format a30
column value format a30
 TTITLE skip 1 LEFT "************* TRANSECTION RELATED PARAMETERS *************************" SKIP 2
 select name,value from v$parameter
 where name like 'transactions%'
/
TTITLE OFF
column value format a50
TTITLE skip 1 LEFT "************* DEFAULT/NON DEFAULT PARAMETERS *************************" SKIP 2
SELECT NAME,VALUE,DECODE(ISDEFAULT,'TRUE','DEFAULT',
				   'FALSE','NON DEFAULT') "TYPE" FROM V$PARAMETER
ORDER BY 3
/
TTITLE OFF
column username format a30
column sql_text format a80
TTITLE skip 1 LEFT "************* SESSIONS WHOSE SQLS ARE FETCHING MORE THAN 5000 BLOCKS*************" skip 2 
select username,sid,serial#,sql_text, buffer_gets, disk_reads,executions, 
buffer_gets/decode(executions,0,1,EXECUTIONS) avg_gets_per_exe
from v$session a, v$sqlarea b
where a.sql_hash_value = b.hash_value
and buffer_gets/decode(executions,0,1,EXECUTIONS) > 5000
order by 8 desc
/
TTITLE OFF

TTITLE skip 1 LEFT "************* Database Archive Log Size (Last 5 Days)*************" skip 2
select trunc(COMPLETION_TIME) TIME, SUM(BLOCKS * BLOCK_SIZE)/1024/1024 SIZE_MB from V$ARCHIVED_LOG where trunc(COMPLETION_TIME)> sysdate -5 group by trunc (COMPLETION_TIME) order by 1
/
TTITLE OFF
TTITLE skip 1 LEFT "************* Database Alert Log Errors in Last 2 Days *************" skip 2
select distinct originating_timestamp, message_text from  x$dbgalertext where  originating_timestamp > sysdate-2 and  message_text like 'ORA-%'
/
TTITLE OFF

col status format a30
TTITLE skip 1 LEFT "************* Database Backup Information *************" skip 2
select SESSION_KEY, INPUT_TYPE, STATUS, to_char(START_TIME,'mm/dd/yy hh24:mi') start_time, to_char(END_TIME,'mm/dd/yy hh24:mi') end_time, elapsed_seconds/3600 hrs from V$RMAN_BACKUP_JOB_DETAILS where trunc(END_TIME) > sysdate -5 order by session_key
/
TTITLE OFF

col OWNER for a10
col CREATION_TIME for a30
col TIME_SUGGESTED for a30
col OBJECT_NAME for a30
col REASON for a60
col MESSAGE_TYPE for a30
TTITLE skip 1 LEFT "************* Database Un-Attened Alerts *************" skip 2
select OWNER, OBJECT_NAME, REASON, CREATION_TIME, TIME_SUGGESTED, MESSAGE_TYPE from dba_outstanding_alerts
/
TTITLE OFF

TTITLE skip 1 LEFT "************* DR Status *************" skip 2
select distinct ARCHIVED_THREAD#, ARCHIVED_SEQ#,  APPLIED_THREAD#, APPLIED_SEQ#, GAP_STATUS, status, SRL, type FROM V$ARCHIVE_DEST_STATUS
/
TTITLE OFF


 spool off


disconnect 

exit

