sqlplus -s /nolog <<SQLCONN
connect / as sysdba
set pagesize 5000
set trimspool on
set headsep off
set heading on
set linesize 1000
SET FEEDBACK OFF
SET ECHO ON
col archive_file for a100
select name, open_mode, database_role from v\$database;
select name "archive_file", sequence#, applied, completion_time from v\$archived_log where to_char(completion_time,'DD-MON-YY')=to_char(SYSDATE-1, 'DD-MON-YY') AND applied='YES' and name is not null;
SQLCONN

