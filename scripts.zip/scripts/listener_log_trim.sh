#!/usr/bin/ksh
#####################################################################
#       Script Name     :       Trim_Listener.sql
#       Date            :       05/20/2011
#       Author          :       Kunal Verma
#       Description     :       Trim Listener Log.To maintain listner
#                               log size less than 500MB
#
#       Usage           :       Trim_Listener.sql {LISTENER_NAME}
#
#       Modified Date   :  06/23/2011
#       By:                  SAURIN
#####################################################################

# Get the script name
set -x
SCRIPT_NAME="/vol01/app/oracle/admin/scripts/purge_files/listener_log_purge.sh"

#####################################################################
# STEP00 : Preliminary Checks
#####################################################################

# Date and Time
DATE=`date +%m/%d/%Y::%H:%M:%S`
LOG="/vol01/app/oracle/admin/scripts/purge_files/listener_log_trim.log"
lsnr=$1

# Check the Input Parameters
if [ -z "$1" ]
then
   echo "Usage: $0 <LISTENER_NAME>"
   exit 1
fi

# Find and Set Oracle Home
ORACLE_HOME=`ps -ef | grep tnslsnr | grep ${lsnr} | awk '{print $8}' | sed s/'\/bin\/tnslsnr'//`
export ORACLE_HOME

# Set Path
PATH=$PATH:$ORACLE_HOME/bin
export PATH

# Set Temp files
PROC_ID=$$
TMP="/tmp/${lsnr}_${PROC_ID}.txt"



#####################################################################
# STEP01 : Check for Listener File
#####################################################################


## Collect Listener name

# Accept listener name as input parameter


lsnr_log=`lsnrctl status ${lsnr} | grep "Listener Log File" | awk '{ print $4}' | sed s/'\/alert\/log.xml'/'\/trace\/listener.log'/`

lsnr_log_bkup=${lsnr_log}.`date '+%Y%m%d%H%M%S'`

lsnr_log_tmp_bkup=${lsnr_log}_temp.`date '+%Y%m%d%H%M%S'`

lsnr_size_kb=`du -sk ${lsnr_log} | awk '{print $1}'`


echo "#####################################################################" >> ${LOG}
echo "Date of maintenance               : `date` "             >> ${LOG}
echo "Oracle Home                       : ${ORACLE_HOME}"       >> ${LOG}
echo "Listener Name                     : ${lsnr}"              >> ${LOG}
echo "PATH                              : $PATH"                >> ${LOG}
echo "Listener Log File                 : ${lsnr_log}"          >> ${LOG}
echo "Listener Log Size                 : ${lsnr_size_kb} KB"   >> ${LOG}
echo "#####################################################################" >> ${LOG}

# Trim Listener log if more than 10M size

if [ -z ${lsnr_log} ]
then
  echo "Error : No listener found"  >> ${LOG}
  exit 1
else
if [ ${lsnr_size_kb} -gt 512 ]
then
   echo "[Listener Log before trim]" >> ${LOG}
   ls -l ${lsnr_log} >> ${LOG}

echo "Listener Log File Backup : ${lsnr_log_bkup}"  >> ${LOG}
cp ${lsnr_log} ${lsnr_log_bkup} >> ${LOG}

if [ $? -ne 0 ]
 then
  echo "Error: ${lsnr_log} file copy failed"
  exit 1
fi

echo " " > ${lsnr_log} >> ${LOG}


echo "[Listener Log after trim]" >>${LOG}
ls -l ${lsnr_log} >>${LOG}

else
   echo "Listener size is less than 10M.Trim not required." >> ${LOG}
fi

fi

#####################################################################
# STEP01 : GZIP the file
#####################################################################

echo "now we gzip it " >> ${LOG}
echo "-------------------------------------" >> ${LOG}

gzip "${lsnr_log_bkup}" >> ${LOG}

#cd $ORACLE_HOME/network/log
cd `dirname ${lsnr_log}`
if test $? -ne 0
then
   echo "Error: Could not reach to listner log directory to remove 180 days old files"  >> ${LOG}
 exit 1
fi

echo "Removing below files which are 180 days old"  >> ${LOG}
/usr/bin/find . -name listener\*.gz -mtime +180 -print  >> ${LOG}
/usr/bin/find . -name listener\*.gz -mtime +180 -exec /bin/rm -f {} \;  >> ${LOG}
echo "Successfull completion of Listener log maintenance job `date`" ;  >> ${LOG}

#cat ${LOG}
#####################################################################

