#!/bin/sh
#set -x
#
# rman_driver.sh
#
# Script to perform Oracle Recover Manager (RMAN) backups of Oracle databases.
#
# Usage:
#    rman_driver.sh [level [SID]]
#
#    level:     The dump level.  Default: 0
#    SID:       The Oracle instance to be backed-up.  Default: $ORACLE_SID
#
# removed deletion of archive logs

#
# Read in Oracle's environment. (ORACLE_HOME, ORACLE_BASE, etc.)

#. /home/oradba/.bash_profile
ORACLE_BASE=/vol01/app/oracle
ORACLE_HOME=/vol01/app/oracle/product/db/12.2.0.1
export ORACLE_HOME
#ORACLE_HOME_LISTNER=$ORACLE_HOME
###ORACLE_SID=MAESTROPRD
export ORACLE_BASE ORACLE_HOME ORACLE_SID
NLS_LANG=_.WE8ISO8859P1
LD_LIBRARY_PATH=$ORACLE_HOME/lib:$LD_LIBRARY_PATH
PATH=$ORACLE_HOME/bin:$PATH
##PATH=`echo $PATH|sed -e 's,[^:]*/oracle/product/[^:]*,,g' -e 's,::,:,g' -e 's,:$,,' -e 's,^:,,'`
export NLS_LANG LD_LIBRARY_PATH PATH


EMAILREC="ETSDBSSQLServerSupport@univision.net"
SAVVIS_DIR=/vol01/app/oracle/admin/scripts

# Configure the backup level.
if [ "x$1" = "x" ]; then
        LEVEL=0
else
        LEVEL=$1
fi
export LEVEL


# Check for the SID.
if [ "x$2" = "x" ] && [ "x$ORACLE_SID" = "x" ]; then
        echo ERROR: ORACLE_SID not specified.
        echo Usage: $0 [level [SID]]
        exit 1
fi

# Save the current ORACLE_SID, if any.
OLD_ORACLE_SID=$ORACLE_SID

# Reset to the new ORACLE_SID.
ORACLE_SID=$2
export ORACLE_SID

# Check for the instance configuration file.
if [ ! -f ${SAVVIS_DIR}/rman_env_INVBIP.sh ]; then
        echo ERROR: Could not locate rman_env_INVBIP.sh configuration file.
        exit 1
fi

# Load in the configuration file.
#echo Loading configuration file rman_env_${ORACLE_SID}.sh
. ${SAVVIS_DIR}/rman_env_INVBIP.sh

# Make the backup directory to hold today's backup if it does not exist.
CUR_DIR="$BACKUP_DIR/$ORACLE_SID/RMANDB-`date '+%Y%m%d-%H%M%S'`"
#echo Creating backup directory $CUR_DIR
if [ ! -d $CUR_DIR ]; then
        mkdir $CUR_DIR
fi
chgrp oinstall $CUR_DIR
chmod 775 $CUR_DIR
LOGFILE=$CUR_DIR/rman-${ORACLE_SID}-`date +'%m%d%y'`.log

NLS_DATE_FORMAT='MON-DD-YY HH24:MI:SS'
export NLS_DATE_FORMAT

#BS_TIME=`sqlplus -silent ipsoft/$IPSOFT_PWD <<END
#BS_TIME=`sqlplus -silent uoldba/uoldbaami027 <<END
#BS_TIME=`sqlplus -silent svadmin/pwd4svadmin <<END
#set pagesize 0 feedback off verify off heading off echo off
#  select '"to_date('''||to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||''',''yyyy-mm-dd hh24:mi:ss'')"' from dual;
#exit
#END`

# change archivelog all crosscheck;

echo "$ORACLE_SID: RMAN backup taking off on `date +'%m%d%y'` at `date +'%H%M%S'`" |tee -a $LOGFILE 
echo " " >> $LOGFILE
#rman nocatalog << EOF
( /vol01/app/oracle/product/db/12.2.0.1/bin/rman nocatalog <<EOF
@/vol01/app/oracle/admin/scripts/connect${ORACLE_SID}.rman
 configure controlfile autobackup format for device type disk to '${CUR_DIR}/ctrl_%F';
configure controlfile autobackup ON;
run { allocate channel ch1 type disk format '${CUR_DIR}/bk_%s_%p_%t' maxopenfiles 1;
      allocate channel ch2 type disk format '${CUR_DIR}/bk_%s_%p_%t' maxopenfiles 1;
##	shutdown immediate
##	startup mount
		backup current controlfile format '${CUR_DIR}/ctl_%s_%p_%t';
        backup incremental level ${LEVEL} filesperset 1
## 	backup full database filesperset 1
	(database format '${CUR_DIR}/bk_%s_%p_%t');
##		sql 'alter database open';
	sql 'alter system archive log current';
	backup format '${CUR_DIR}/arc_%s_%p_%t' (archivelog all );
	delete noprompt archivelog until time 'sysdate-2';
		backup current controlfile format '${CUR_DIR}/ctl_%s_%p_%t';
		sql 'ALTER DATABASE BACKUP CONTROLFILE TO TRACE';
        release channel ch1; 
        release channel ch2;
     }
configure controlfile autobackup format for device type disk to '${BACKUP_DIR}/${ORACLE_SID}/ctrl_%F';
EOF
) | tee -a $LOGFILE

if [ $? -ne 0 ] || [ `egrep -i 'ora-|error|failure' $LOGFILE |wc -l` -ne 0 ] ; then
        #echo "ERROR: RMAN backup failed."
/usr/bin/mailx -s "$ORACLE_SID OFFLINE DD RMAN: FAILED" ETSDBSSQLServerSupport@univision.net  < $LOGFILE
###/bin/mailx -s "$ORACLE_SID@`hostname` DD RMAN: FAILED" dbaradar@ip-soft.net <$CUR_DIR/rman-${ORACLE_SID}-`date +'%m%d%y'`
cp $LOGFILE /vol01/app/oracle/admin/scripts/db_backup/log
exit
fi

echo " " >> $LOGFILE
echo "$ORACLE_SID: RMAN backup ending on `date +'%m%d%y'` at `date +'%H%M%S'`" |tee -a $LOGFILE
echo " " >> $LOGFILE

# Now, compress the backup and archive log files.
#cd $CUR_DIR
#gzip *.bak *.arc
#if [ $? -ne 0 ]; then
#echo "ERROR: gzip compress failed."
#/bin/mailx -s "RMAN: `hostname` $ORACLE_SID compress FAILED" dbaradar@ip-soft.net < $CUR_DIR/rman-${ORACLE_SID}-`date +'%m%d%y'`
#exit
#fi

echo " "  >> $LOGFILE
echo "List of backup files:" >> $LOGFILE
echo "=====================" >> $LOGFILE
ls -lrt  $CUR_DIR/*          >> $LOGFILE 

#OK everything finished.
/usr/bin/mailx -s "$ORACLE_SID OFFLINE DD RMAN: completed successfully." $EMAILREC < $LOGFILE

# Reset ORACLE_SID to OLD_ORACLE_SID
if [ "x$OLD_ORACLE_SID" = "x" ]; then
        ORACLE_SID=""
else
        ORACLE_SID=$OLD_ORACLE_SID
        export ORACLE_SID
fi

#echo "Ending rman_driver.sh"
cp $LOGFILE /vol01/app/oracle/admin/scripts/db_backup/log
exit 0


