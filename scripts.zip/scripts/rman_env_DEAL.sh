#!/bin/sh
#
#
# The following variables are used by rman_driver.sh
#
# BACKUP_DIR
# Description:  This is the location of the directory where rman_driver.sh will
#output its files.
# There must be enough space on this partition in order to accommodate for all t
#he backup files.
# If there is not, rman_driver.sh will fail.
# Possible values:  any valid UNIX directory.
# Example:  BACKUP_DIR=/export/oracle/backup
#
# LOG_DIR
# Description:  Location of the log file for this instance.  The file is named a
#fter the instance.
# Possible values:  any valid UNIX directory.


ARCH_DIR=/deal-03/arch/DEAL
SAVED_DIR=/deal-03/arch/DEAL/saved
R_SAVED_DIR="/app/mia-localdb/oracle/DEAL/arch/saved"
ARCH_BACKUP_DIR=/app/nj-dd01/local/oracle/DEAL/arch
BACKUP_DIR=/app/mia-miadb/oracle/fl1-deal-porcl3
RETENTION=1
ARCH_RETENTION=0
SAVED_RETENTION=2
R_SAVED_RETENTION=7
DBF_BKUP_RETENTION=31
ARC1_DIR=/deal-03/arch/DEAL
SAVVIS_PWD=svvs123
ORADBA_DIR=/vol01/app/oracle/admin/scripts
STATSPACK_UID=perfstat/p0rfst3t
export BACKUP_DIR ARC1_DIR SAVVIS_PWD ORADBA_DIR  SAVED_DIR R_SAVED_DIR STATSPACK_UID RETENTION SAVED_RETENTION R_SAVED_RETENTION ORADBA_DIR ARCH_BACKUP_DIR DBF_BKUP_RETENTION

