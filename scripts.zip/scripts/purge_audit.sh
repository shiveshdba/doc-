echo -e "The following files will be purged :\n" > audit_purge.log
echo -e "\n"  >> audit_purge.log

/usr/bin/find /vol01/app/oracle/product/db/12.2.0.1/rdbms/audit -name "*.aud" -type f -mtime +90 >> audit_purge.log
/usr/bin/find /vol01/app/oracle/product/db/12.2.0.1/rdbms/audit -name "*.aud" -type f -mtime +90 -exec rm -f {} \;
