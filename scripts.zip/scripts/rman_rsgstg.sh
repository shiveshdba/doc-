# Oracle Settings
export TMP=/tmp
export TMPDIR=$TMP
export ORACLE_HOSTNAME=fl1-gen-qorc3
export ORACLE_UNQNAME=RSGSTG
export ORACLE_BASE=/vol01/app/oracle
export ORACLE_HOME=$ORACLE_BASE/product/db/12.1.0.2
export ORACLE_SID=RSGSTG
export PATH=/usr/sbin:$PATH
export PATH=$ORACLE_HOME/bin:$PATH
export LD_LIBRARY_PATH=$ORACLE_HOME/lib:/lib:/usr/lib
export CLASSPATH=$ORACLE_HOME/jlib:$ORACLE_HOME/rdbms/jlib
echo "connected to 12c database"
#######################################################################################
export BACKUP_DIR=/app/mia-miadb/oracle/fl1-rsg-porcl1
export CUR_DIR=$BACKUP_DIR/RSGPRD
echo $CUR_DIR
cd $CUR_DIR
export CTRL=`ls -ltr | tail -1 | awk {'print $9'}`
echo $CTRL
cd $CUR_DIR/$CTRL
export CONTROLFILE=`ls -ltr ctrl* | tail -1 | awk {'print $9'}`
echo $CONTROLFILE
#
rman target=/ << EOF
shutdown immediate;
startup nomount;
restore controlfile from '$CUR_DIR/$CTRL/$CONTROLFILE';
alter database mount;
catalog start with '/app/mia-miadb/oracle/fl1-rsg-porcl1/RSGPRD' noprompt;
select member from v\$logfile;
LIST BACKUP SUMMARY;
@/vol01/app/oracle/admin/scripts/rman_RSGSTG.rman
EXIT;
EOF
######################################
sqlplus / as sysdba << SQL
select name, open_mode,log_mode from v\$database;
alter database noarchivelog;
alter database open resetlogs;
select * from dba_temp_files;
alter database default temporary tablespace RLTEMP;
drop tablespace temp including contents and datafiles;
host rm /rsgstg-01/oradata/rsgstg/temp01.dbf
CREATE TEMPORARY TABLESPACE "TEMP" TEMPFILE '/rsgstg-01/oradata/rsgstg/temp01.dbf' SIZE 1315962880 AUTOEXTEND ON NEXT 655360 MAXSIZE 32767M
EXTENT MANAGEMENT LOCAL UNIFORM SIZE 1048576;
alter database default temporary tablespace TEMP;
drop tablespace RLTEMP including contents and datafiles;
host rm /rsgstg-01/oradata/rsgstg/rltemp01.dbf
CREATE TEMPORARY TABLESPACE "RLTEMP" TEMPFILE '/rsgstg-01/oradata/rsgstg/rltemp01.dbf' SIZE 3221225472 AUTOEXTEND ON NEXT 209715200 MAXSIZE 3072M
EXTENT MANAGEMENT LOCAL UNIFORM SIZE 1048576;
select * from dba_temp_files;
alter user RLVIEWER temporary tablespace RLTEMP;
alter user IPPRODUCTS temporary tablespace RLTEMP;
alter user RLREPORTS temporary tablespace RLTEMP;
alter user RLROCP temporary tablespace RLTEMP;
alter user RLCRM temporary tablespace RLTEMP;
alter user RLFINANCE temporary tablespace RLTEMP;
alter user RLREELS temporary tablespace RLTEMP;
alter user RLWORKFLOW temporary tablespace RLTEMP;
alter user RLASSETS temporary tablespace RLTEMP;
alter user RLRTSOUT temporary tablespace RLTEMP;
alter user LGAHDATA temporary tablespace RLTEMP;
alter user RLANLTCS temporary tablespace RLTEMP;
alter user RLPPS temporary tablespace RLTEMP;
alter user RLEXTRANET temporary tablespace RLTEMP;
alter user RLPRDHUB temporary tablespace RLTEMP;
alter user RLRTSIN temporary tablespace RLTEMP;
alter user RLCPVERSION temporary tablespace RLTEMP;
alter user RLADMIN temporary tablespace RLTEMP;
alter user RLVERSION temporary tablespace RLTEMP;
alter user RLSTAGE temporary tablespace RLTEMP;
alter user RLAPP temporary tablespace RLTEMP;
@/vol01/app/oracle/admin/scripts/RB_drop_scheduler.sql
exit;
SQL
#########################################################
# Send Mail:-
echo "Check attached log and review it." | mailx -s "RSGSTG Refresh has been completed with latest backup" -a "/tmp/rman_RSGSTG_refresh.log" ETSDBSOracleServerSupport@univision.net

