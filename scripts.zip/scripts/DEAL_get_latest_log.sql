connect / as sysdba;
set echo off feed off head off pages 0 trims on
alter system switch logfile;
spool /tmp/DEAL_latest_log.out
select max(sequence#) from gv$log_history where resetlogs_time >=(select max(resetlogs_time) from  gv$log_history);
spool off
exit;
