#/bin/ksh
#set -x

SetVariables()
{
set_ORACLE_SID;
JOB=exp_dp
INIT_JOB;
echo "set"
EXP_DIR=/app/mia-localdb/oracle/export
LOCKFILE="${JOB_LOCATION}/exp_dp_$ORACLE_SID${etyp}.lock"
echo "LOCKFILE : ${LOCKFILE}" >> $JOB_LOG
Dt=`date '+%m%d%y-%H-%M'`
TMPFILE="${JOB_LOG}.tmp"
MAILFILE="${JOB_LOG}.mail"
USRNAME=SAVVIS
PASSWD=$SAVVIS_PWD

if [ ! -d $EXP_DIR ] || [ ! -d $EXP_DIR/$ORACLE_SID/log/ ]; then
 echo "$EXP_DIR not exist." >>  ${JOB_LOG}
 /usr/bin/mailx -s "$EXP_DIR or $EXP_DIR/$ORACLE_SID/log/ not exist on `hostname` Server" $FAIL_MAIL_ADDRESS < /dev/null
 FAILURE_UPDATE;
 exit
fi
}


# ======================================================================
# Main Code
# ======================================================================

. /vol01/app/oracle/admin/scripts/.bash_profile_DEAL
Usage()
{
   echo " Usage -s SID -t type of export -m remote server copy info. -l local retention -r remote retention -h help "
   echo " eg. export_univision.sh Pora026 ATG,PRV xtransfer@u1350:/cust/oracle/exports 10 1"
   echo " -s ORACLE_SID "
   echo " -t Type of export backup (ALL for full backup or spcify the schema name for partial export "
   echo " -l Retention period in local disk"
   exit 1
}

while getopts s:t:l: opts
do
     case ${opts} in
          s)
             ORACLE_SID=${OPTARG}
             ;;
          t)
             EXP_TYPE=${OPTARG}
             ;;
          l)
             L_RET=${OPTARG}
             ;;
          h)
             Usage;;

          \?)
             print $OPTARG is not a valid argument! 1>&2
             Usage
             exit 2
             ;;
     esac
done

if [ -z "${ORACLE_SID}" ];
    then  echo "Error: -s arg must be defined!"
    Usage
fi

if [ -z "${EXP_TYPE}" ];
    then  echo "Error: -t arg must be defined!"
    Usage
fi


if [ -z "${L_RET}" ];
    then  echo "Error: -l arg must be defined!"
    Usage
fi

EXP_TYPE=`echo $EXP_TYPE|tr '[a-z]' '[A-Z]'`
if [ $EXP_TYPE = "ALL" ]; then
   EXP_TP="FULL=Y"
   M_SUB="Full"
   etyp=""
else
   EXP_TP="SCHEMAS=$EXP_TYPE"
#   echo "List of schemas to be exported:$EXP_TYPE" >> $JOB_LOG
   M_SUB="Schema"
   etyp="_schema"
fi


. /vol01/app/oracle/admin/scripts/svvs_lib.sh

SetVariables ;

echo "set2"
echo "$ORACLE_SID Export taking off on `date '+%m%d%y'` at `date '+%H%M%S'`" >> $JOB_LOG

echo "List of arguments:" >> $JOB_LOG
echo "-s $ORACLE_SID -t $EXP_TYPE -m -$REXP_DIR -l $L_RET -r $R_RET " >> $JOB_LOG

echo " " >> $JOB_LOG
echo "List of schemas to be exported:$EXP_TYPE" >> $JOB_LOG
echo " " >> $JOB_LOG

   EXP_DMP_FILE=oraexp_dp_${ORACLE_SID}${etyp}.dmp
   EXP_DMP_FILE1=oraexp_dp_${ORACLE_SID}${etyp}.dmp
   EXP_LOG_FILE=oraexp_dp_${ORACLE_SID}${etyp}.log

# ----------------------------------------------------------------------
# Set the default parameters.
# ----------------------------------------------------------------------
DIRECTORY=EXP_DPUMP
DUMPFILE=oraexp_dp_${ORACLE_SID}${etyp}.dmp
DP_JOB_LOG=oraexp_dp_${ORACLE_SID}${etyp}.log
DP_PARFILE=${JOB_LOCATION}/expdp_${ORACLE_SID}.par

# ----------------------------------------------------------------------
# Make sure that only one instance is running.
# ----------------------------------------------------------------------

echo $LOCKFILE

if test -f "${LOCKFILE}"
then
 echo "Another expdp is already running." >> $JOB_LOG
    /usr/bin/mailx -s "Another expdp is already running $ORACLE_SID on `hostname` Server. Check the status." $FAIL_MAIL_ADDRESS < /dev/null
  echo "Another expdp is already running $ORACLE_SID on `hostname` Server" | /usr/bin/mailx -s "$ORACLE_SID $M_SUB DP export:Failed" $SUCCESS_MAIL_ADDRESS
  cat $JOB_LOG
  FAILURE_UPDATE ;
 exit 1
fi

echo $Dt > ${LOCKFILE}

if [ ! -d $EXP_DIR/$ORACLE_SID ] || [ ! -w $EXP_DIR/$ORACLE_SID ] ; then
  echo "Error writing to export directory DIR=$EXP_DIR" >> $JOB_LOG
    /usr/bin/mailx -s "Error writing to export directory DIR=$EXP_DIR $ORACLE_SID on `hostname` Server. Check the status." $FAIL_MAIL_ADDRESS < /dev/null
echo "Error writing to export directory DIR=$EXP_DIR $ORACLE_SID on `hostname` Server. Check the status."|  /usr/bin/mailx -s "$ORACLE_SID $M_SUB DP export: Failed" $SUCCESS_MAIL_ADDRESS
rm ${LOCKFILE}
  cat $JOB_LOG
  FAILURE_UPDATE ;
  exit 1
fi

# Location of export dump file
echo "===========================================" >> $JOB_LOG
echo "`date '+%H:%M'` File suffle in local server " >> $JOB_LOG

#--------------------------------------------------------------------------
# Shuffle old exports back
#--------------------------------------------------------------------------
cd ${EXP_DIR}/$ORACLE_SID/

INDEXP1=0
if [ ${L_RET} -gt 0 ] ; then

  INDEX=${L_RET}
  rm -f ${EXP_DMP_FILE}.${L_RET}
  while : ; do
    (( INDEX = INDEX - 1 ))
    if [ $INDEX -eq 0 ] ; then
      break
    fi
    (( INDEXP1 = INDEX + 1 ))
    if [ -r ${EXP_DMP_FILE}.${INDEX} ] ; then
      echo "`date '+%H:%M'` Moving file ${EXP_DMP_FILE}.${INDEX} to ${EXP_DMP_FILE}.${INDEXP1}" >> $JOB_LOG
      mv -f  ${EXP_DMP_FILE}.${INDEX}  ${EXP_DMP_FILE}.${INDEXP1}
    fi
  done
  if [ -r ${EXP_DMP_FILE} ] ; then
   echo "`date '+%H:%M'` Moving file ${EXP_DMP_FILE} to  ${EXP_DMP_FILE}.1" >> $JOB_LOG
    mv -f ${EXP_DMP_FILE} ${EXP_DMP_FILE}.1
  fi
fi

#****************************************************************
#JOB_LOG
#****************************************************************
INDLGF1=0
if [ ${L_RET} -gt 0 ] ; then

  INDLGF=${L_RET}
  rm -f ${EXP_LOG_FILE}.${L_RET}
  while : ; do
    (( INDLGF = INDLGF - 1 ))
    if [ $INDLGF -eq 0 ] ; then
      break
    fi
    (( INDLGF1 = INDLGF + 1 ))
    if [ -r ${EXP_LOG_FILE}.${INDLGF} ] ; then
      echo "`date '+%H:%M'` Moving file ${EXP_LOG_FILE}.${INDLGF} to ${EXP_LOG_FILE}.${INDLGF1}" >> $JOB_LOG
      mv -f  ${EXP_LOG_FILE}.${INDLGF}  ${EXP_LOG_FILE}.${INDLGF1}
    fi
  done
  if [ -r ${EXP_LOG_FILE} ] ; then
   echo "`date '+%H:%M'` Moving file ${EXP_LOG_FILE} to  ${EXP_LOG_FILE}.1" >> $JOB_LOG
    mv -f ${EXP_LOG_FILE} ${EXP_LOG_FILE}.1
  fi
fi

#####################

#------------------------------------------
#Shuffle export dumpfiles in remote location
#--------------------------------------------
echo "===========================================" >> $JOB_LOG
#echo "`date '+%H:%M'` File suffle in remote server " >> $JOB_LOG
#source_s=`hostname`":/tmp"


#####
ZERO="0"
YES="Y"
SUBJ=""

c=1

while [[ $c -le 3 ]]; do

exp_stdt="`date +'%Y%m%d%H%M%S'`"

#--------------------------------------------------------------------------
# Perform the export
#--------------------------------------------------------------------------

echo "expdp $USRNAME \
   DIRECTORY=$DIRECTORY \
   DUMPFILE=$DUMPFILE \
   LOGFILE=$DP_JOB_LOG \
   PARFILE=$DP_PARFILE \
   $EXP_TP " >> $JOB_LOG
   # $EXP_TP flashback_time=\\\"TO_TIMESTAMP\(SYSDATE\)\\\" " >> $JOB_LOG

expdp $USRNAME \
   DIRECTORY=$DIRECTORY \
   DUMPFILE=$DUMPFILE \
   LOGFILE=$DP_JOB_LOG \
   PARFILE=$DP_PARFILE \
  $EXP_TP > $TMPFILE 2>&1 <<!EOF
$PASSWD
!EOF

exp_eddt="`date +'%Y%m%d%H%M%S'`"

cat $TMPFILE|grep -v $PASSWD >> nopass1
mv nopass1 $TMPFILE

if [[ -z "`grep 'successfully completed at' $TMPFILE`" ]] ; then

    echo "Exported with warnings"
    IgCnt=`egrep -i 'ORA-01466' $TMPFILE |wc -l`
    echo "IgnoreCount(ora-01466): $IgCnt"

    ErrCnt=`egrep -i "error\(s\)" $TMPFILE |wc -l`
    ErrCnt=`egrep -i "error|error\(s\)" $TMPFILE |wc -l`
    echo "Errors Str Count: $ErrCnt"

    if [ $ErrCnt -eq  $ZERO ] ; then
       echo "NoErrors"
       SUBJ="${ORACLE_SID} $M_SUB DP export: completed successfully "
       c=9
       break;
    else
       ERRSTR="`grep -i 'error(s)' $TMPFILE`"
       DPERR="`echo $ERRSTR | awk '{print $5}'`"

       echo "STR: $ERRSTR"
       echo "ExportJobErrorCount: $DPERR"

       if [[ "$DPERR" == [0-9] ]] ; then

          if [ $IgCnt -eq $DPERR ] ; then
             echo "DumpFile to compress and scp "
             SUBJ="${ORACLE_SID} $M_SUB DP export: completed successfully with known warnings"
             c=9
             break;
          else
             echo "Export to rerun DumpErrors: $DPERR Ignore: $IgCnt"
             # Remove dump file
               cat $TMPFILE |  /usr/bin/mailx -s "$ORACLE_SID $M_SUB DP export: FAILED. Re running the job" $FAIL_MAIL_ADDRESS
               cat $TMPFILE
               echo "$ORACLE_SID $M_SUB DP export: FAILED. Re running the job"
               mv $EXP_DIR/$ORACLE_SID/$DP_JOB_LOG  $EXP_DIR/$ORACLE_SID/$DP_JOB_LOG.$$
               rm -f $EXP_DIR/$ORACLE_SID/$DUMPFILE
               (( c++ ))
          fi

       else
               echo "ExportJobErrorCount: Non Number"
               if [ $IgCnt -gt 0 ] ; then
                     SUBJ="${ORACLE_SID} $M_SUB DP export: completed successfully with known warnings"
                     c=9
                     break;
               else
                     # Remove dump file
                       cat $TMPFILE |  /usr/bin/mailx -s "$ORACLE_SID $M_SUB DP export: FAILED. Re running the job" $FAIL_MAIL_ADDRESS
                       cat $TMPFILE
                       echo "$ORACLE_SID $M_SUB DP export: FAILED. Re running the job"
                       mv $EXP_DIR/$ORACLE_SID/$DP_JOB_LOG  $EXP_DIR/$ORACLE_SID/$DP_JOB_LOG.$$
                       rm -f $EXP_DIR/$ORACLE_SID/$DUMPFILE
                       (( c++ ))
                fi
       fi
    fi

# --------
else
    SUBJ="${ORACLE_SID} $M_SUB DP export: completed successfully "
    echo "Exported sucessfully"
    c=9
    break;

# ------------
fi

done

#####




chmod o+r $EXP_DIR/$ORACLE_SID/$EXP_DMP_FILE


scp_sdt="`date +'%Y%m%d%H%M%S'`"

echo "Date format is (yyyymmddhhmiss) " > $MAILFILE
echo " " >> $MAILFILE
echo "Export Start time: $exp_stdt" >> $MAILFILE
echo "Export End  time : $exp_eddt" >> $MAILFILE
echo " " >> $MAILFILE
echo "Export dump file :" >> $MAILFILE
ls -l ${EXP_DIR}/${ORACLE_SID}/oraexp_dp_${ORACLE_SID}*dmp* >> $MAILFILE
echo " " >> $MAILFILE
echo "Export Logfile of ${ORACLE_SID}:" >> $MAILFILE
#cat $TMPFILE|grep -v $PASSWD >> $MAILFILE
cat $EXP_DIR/$ORACLE_SID/$DP_JOB_LOG >> $MAILFILE

echo "Mail subject:$M_SUB" >> $JOB_LOG
echo "email subj: $SUBJ"

cat $MAILFILE|/usr/bin/mailx -s "${SUBJ} " ${SUCCESS_MAIL_ADDRESS}
SUCCESS_UPDATE;

#Remove lock file
rm $LOCKFILE

echo " " >> $JOB_LOG
echo "Summary of export:" >> $JOB_LOG
echo "==================" >> $JOB_LOG
cat $MAILFILE >> $JOB_LOG

echo " " >> $JOB_LOG
echo "Export ending on `date '+%m%d%y'` at `date '+%H%M%S'`" >> $JOB_LOG

exit 1

#EOS -----

