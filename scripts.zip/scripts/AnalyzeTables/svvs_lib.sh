## SAVVIS SCRIPT WRAPPER

MAIN_SCRIPT_LOCATION=/vol01/app/oracle/admin/scripts
DATE=`date '+%m%d%y'` ;
TIME=`date '+%H%M%S'` ;
DT_TM=`date '+%m%d%y_%H%M%S'` ;
export DATE ;
export TIME ;
export DT_TM ;
FAIL_MAIL_ADDRESS="ETSDBSOracleServerSupport@univision.net"
SUCCESS_MAIL_ADDRESS="ETSDBSOracleServerSupport@univision.net"
FAILURE_MESSAGE=""
JOB_LOCATION=""
JOB_SQL_LOG=""
JOB_LOG=""
JOB_SUMMARY_LOG=""
SAVVIS_PWD="uim30vol"

DT( )
{
DATE=`date '+%m%d%y'` ;
TIME=`date '+%H%M%S'` ;
DT_TM=`date '+%m%d%y_%H%M%S'` ;
export DATE ;
export TIME ;
export DT_TM ;
}

INIT_JOB()
{
JOB_LOCATION="${MAIN_SCRIPT_LOCATION}/${JOB}"
JOB_SQL_LOG="${JOB_LOCATION}/log/${JOB}.${DT_TM}.${ORACLE_SID}.sql.log"
JOB_LOG="${JOB_LOCATION}/log/${JOB}.${DT_TM}.${ORACLE_SID}.log"
JOB_SUMMARY_LOG="${JOB_LOCATION}/${JOB}_summary"
}

SUCCESS_MAIL()
{
   T_DT_TM="`date '+%m/%d/%y %H:%M:%S'`"
   T_LOGFILE=$1
   if [ -z "$T_LOGFILE" ]
   then
       T_LOGFILE=$JOB_LOG ;
   fi
   T_SUBJECT=$2
   if [ -z "$T_SUBJECT" ]
   then
    T_SUBJECT="${ORACLE_SID} ${JOB}: Completed successfully"
#    T_SUBJECT="SUCCESS: ${JOB} SID:${ORACLE_SID} on `hostname` at ${T_DT_TM}"
   fi
   cat $T_LOGFILE | mailx -s "${T_SUBJECT}" $SUCCESS_MAIL_ADDRESS

#   echo $T_LOGFILE $T_SUBJECT
}

FAIL_MAIL()
{
   T_DT_TM="`date '+%m/%d/%y %H:%M:%S'`"
   T_LOGFILE=$1
   if [ -z "$T_LOGFILE" ]
   then
       T_LOGFILE=$JOB_LOG ;
   fi
   T_SUBJECT=$2
   if [ -z "$T_SUBJECT" ]
   then
    T_SUBJECT="${ORACLE_SID} ${JOB}: Failed"
#     T_SUBJECT="FAILED: ${JOB} SID:${ORACLE_SID} on `hostname` at ${T_DT_TM}"
   fi
   cat $T_LOGFILE | mailx -s "$T_SUBJECT" $FAIL_MAIL_ADDRESS

}

SUCCESS_UPDATE()
{
 ## 1st parameter should be JOB LOG file
 ## 2nd parameter should be JOB MESSAGE
   T_DT_TM="`date '+%m/%d/%y %H:%M:%S'`"
   T_SUMMARY_LOG=$1
   if [ -z "$T_SUMMARY_LOG" ]
   then
       T_SUMMARY_LOG=$JOB_SUMMARY_LOG
   fi
   T_MESSAGE=$2
   if [ -z "$T_MESSAGE" ]
   then
     T_MESSAGE="SUCCESS: ${JOB} SID:${ORACLE_SID} on `hostname` at ${T_DT_TM}"
   fi
#   echo $T_SUMMARY_LOG $T_MESSAG -
   echo "${T_MESSAGE}" >> $T_SUMMARY_LOG
   echo "${T_MESSAGE}"
}

FAILURE_UPDATE()
{
 ## 1st parameter should be JOB LOG file
 ## 2nd parameter should be JOB MESSAGE
   T_DT_TM="`date '+%m/%d/%y %H:%M:%S'`"
   T_SUMMARY_LOG=$1
   if [ -z "$T_SUMMARY_LOG" ]
   then
       T_SUMMARY_LOG=$JOB_SUMMARY_LOG
   fi
   T_FAILURE_MESSAGE=${FAILURE_MESSAGE:=" "}
   T_MESSAGE=$2
   if [ -z "$T_MESSAGE" ]
   then
   T_MESSAGE="ERROR: ${JOB} Failed SID:${ORACLE_SID} on `hostname` $T_FAILURE_MESSAGE at ${T_DT_TM}"
   fi
   echo "${T_MESSAGE}" >> $T_SUMMARY_LOG
   echo "${T_MESSAGE}"
}


ZIP_LOG_FILE()
{
 T_LOGFILE=$1
  if [ -z "$T_LOGFILE" ]
   then
       T_LOGFILE=$JOB_LOG ;
   fi
   zip $T_LOGFILE ;
}


REMOVE_OLD_FILES()
{
  T_RETENTION_TIME=$1
  T_LOCATON=${2}
  if [ -Z "$T_LOCATION" ]
  then
    T_LOCATION="${JOB_LOCATION}/log"
  fi
  if [ -Z "$JOB" ]
  then
    echo "NO JOB defined for file removal"
  else
    find $T_LOCATION -name "${JOB}\*.log" -mtime +${T_RETENTION_TIME} -exec rm -f {} \;
  fi
}

set_ORACLE_SID()
{
  tmp1029="^${ORACLE_SID}:"
  ORACLE_HOME="`grep $tmp1029 /etc/oratab | cut -d: -f2`"
  export ORACLE_HOME
  PATH=$ORACLE_HOME/bin:$PATH
  LD_LIBRAY_PATH=$ORACLE_HOME/lib
  export PATH LD_LIBRAY_PATH
}

