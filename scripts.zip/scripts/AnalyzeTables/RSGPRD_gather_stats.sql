set timing on
set feedback off
set linesize 300
col TABLE_NAME for a40
col OWNER for a30
col LAST_ANALYZED for a40
select distinct TABLE_NAME, OWNER,LAST_ANALYZED,STALE_STATS from DBA_TAB_STATISTICS where STALE_STATS='YES' and owner like 'RL%' order by owner;
exec PRC_RL_IDX_RBLD_GAT_STAT;
select distinct TABLE_NAME, OWNER,LAST_ANALYZED,STALE_STATS from DBA_TAB_STATISTICS where STALE_STATS='YES' and owner like 'RL%' order by owner;
exit


