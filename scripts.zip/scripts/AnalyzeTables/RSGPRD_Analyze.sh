#!/bin/bash
#  This script invokes gather stats to perform update statistics and Rebuild Indexes online for All the tables for owner
#  Strings 'RL%'on RSGPRD
#
DATE=`date '+%m%d%y'` ;
TIME=`date '+%H%M%S'` ;
DT_TM=`date '+%m%d%y_%H%M%S'` ;
export DATE ;
export TIME ;
export DT_TM ;
ORACLE_BASE=/vol01/app/oracle; export ORACLE_BASE
ORACLE_HOME=/vol01/app/oracle/product/db/12.1.0.2 export ORACLE_HOME
ORACLE_SID=RSGPRD export ORACLE_SID
PATH=$ORACLE_HOME/bin:$PATH  export PATH
LD_LIBRARY_PATH=$ORACLE_HOME/lib:/lib:/usr/lib export LD_LIBRARY_PATH
CLASSPATH=$ORACLE_HOME/jlib:$ORACLE_HOME/rdbms/jlib export CLASSPATH
#
SCRIPTDIR=/vol01/app/oracle/admin/scripts/AnalyzeTables; export SCRIPTDIR
LOGDIR=/vol01/app/oracle/admin/scripts/AnalyzeTables/log; export LOGDIR
LOGDATE=`date '+%y%m%d'`; export LOGDATE
echo "JOb started at `date '+%y%m%d'`" > $LOGDIR/Analyze_log_RSGPRD_$DT_TM.log
sqlplus / as sysdba @/vol01/app/oracle/admin/scripts/AnalyzeTables/RSGPRD_gather_stats.sql >> $LOGDIR/Analyze_log_RSGPRD_$DT_TM.log
exit


