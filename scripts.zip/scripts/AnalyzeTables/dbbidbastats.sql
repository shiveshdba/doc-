spool /home/oracle/gather_stats_bidba.log
Set timing on
Set echo on
select name, open_mode from v$database;
exec dbms_stats.gather_schema_stats('BIDBA',cascade=>true);
set timing off
