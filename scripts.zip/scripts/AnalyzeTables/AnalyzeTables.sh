. /vol01/app/oracle/admin/scripts/AnalyzeTables/svvs_lib.sh
#set -x

ORACLE_SID=$1
export ORACLE_SID
set_ORACLE_SID ;

JOB='AnalyzeTables'
INIT_JOB ;

sqlplus -s /nolog <<-EOF > ${JOB_SQL_LOG}
SET SERVEROUT ON SIZE 1000000 LINES 70 TRIMS ON FEEDBACK OFF
--CONNECT SAVVIS/$SAVVIS_PWD
CONNECT oradba/oradba

column host_name     format A15 Head 'Host'
column instance_name format A10 Head 'Database'
column user          format A12 noprin
column RunDate       format A22

SELECT SUBSTR(host_name,1, INSTR(host_name, '.', 1)-1) host_name,  instance_name, user
       , TO_CHAR(sysdate, 'Mon DD YYYY HH:MI AM') RunDate
FROM v\$instance;

DECLARE

   p_table_owner   varchar2(30) := ' ';
   p_partition     varchar2(64);
   p_part_name     varchar2(64);

BEGIN

    DBMS_OUTPUT.PUT_LINE(chr(10)|| lpad('=',66, '=') );
    FOR r IN
        ( SELECT owner, table_name
            FROM dba_tables
           WHERE  owner NOT IN ('SYS', 'SYSTEM','CTXSYS','DBSNMP','EXFSYS','FLOWS_030000','MDSYS','MGR','OLAPSYS','ORDSYS','OUTLN','SYSMAN','TSMSYS','WKSYS','WK_TEST','WMSYS','XDB')
            AND PARTITIONED = 'NO'
           ORDER BY 1,2
         )
    LOOP

        IF  (p_table_owner <> r.owner)
        THEN

            DBMS_OUTPUT.PUT_LINE (CHR(10)||'Analyzing Schema:'|| r.owner );
            p_table_owner := r.owner;

        END IF;

       BEGIN

          DBMS_OUTPUT.PUT_LINE (chr(9)|| ' Table: '|| RPAD(r.table_name, 30, ' ')||
                  '...'|| TO_CHAR(sysdate, 'Mon DD YYYY HH:MI AM' ) );

          DBMS_STATS.gather_table_stats(r.owner, r.table_name, null,25 ,FALSE
                ,'FOR ALL INDEXED COLUMNS SIZE 1' ,1 , 'ALL',TRUE);

        EXCEPTION
           WHEN OTHERS
           THEN
                DBMS_OUTPUT.put_line(CHR(9)|| ' !!! OracleError: '|| SQLERRM );
        END;

     END LOOP;


    -- Analyze Current Month Partitions --

    p_table_owner := ' ';

    FOR r IN
        ( SELECT table_owner owner, table_name, partition_name
            FROM dba_tab_partitions

            WHERE partition_name like '%'||TO_CHAR(sysdate, 'YYYYMM') || '%'
            AND table_owner NOT IN ('SYS', 'SYSTEM','CTXSYS','DBSNMP','EXFSYS','FLOWS_030000','MDSYS','MGR','OLAPSYS','ORDSYS','OUTLN','SYSMAN','TSMSYS','WKSYS','WK_TEST','WMSYS','XDB')
            ORDER BY 1,2,3
         )
    LOOP

        IF  (p_table_owner <> r.owner)
        THEN

            DBMS_OUTPUT.PUT_LINE (CHR(10)||'Analyzing Schema:'|| r.owner );
            p_table_owner := r.owner;

        END IF;


       BEGIN

          DBMS_OUTPUT.PUT_LINE (CHR(10)|| RPAD(r.table_name||':'||r.partition_name, 46, ' ')||
                  '...'|| TO_CHAR(sysdate, 'Mon DD YYYY HH:MI AM' ) );

          DBMS_STATS.gather_table_stats(r.owner, r.table_name, r.partition_name,25 ,FALSE
                ,'FOR ALL INDEXED COLUMNS SIZE 1' ,DBMS_STATS.DEFAULT_DEGREE, 'PARTITION',TRUE);

        EXCEPTION
           WHEN OTHERS
           THEN
                DBMS_OUTPUT.put_line(CHR(9)|| ' !!! OracleError: '|| SQLERRM );

        END;

        p_partition := r.partition_name;

        FOR i IN 1..3
        LOOP

            BEGIN
               SELECT MAX(partition_name)
                 INTO p_part_name
                 FROM dba_tab_partitions
               WHERE  table_owner = r.owner
                 AND  table_name  = r.table_name
                 AND  partition_name < p_partition;
            EXCEPTION
                 WHEN OTHERS THEN
                DBMS_OUTPUT.put_line(CHR(9)|| ' !!! OracleError: '|| SQLERRM );
            END;

       BEGIN

          DBMS_OUTPUT.PUT_LINE (RPAD(r.table_name||':'||p_part_name, 46, ' ')||
                  '...'|| TO_CHAR(sysdate, 'Mon DD YYYY HH:MI AM' ) );

          DBMS_STATS.gather_table_stats(r.owner, r.table_name, p_part_name,25 ,FALSE
                ,'FOR ALL INDEXED COLUMNS SIZE 1' ,DBMS_STATS.DEFAULT_DEGREE, 'PARTITION',TRUE);

        EXCEPTION
           WHEN OTHERS
           THEN
                DBMS_OUTPUT.put_line(CHR(9)|| ' !!! OracleError: '|| SQLERRM );

        END;

        p_partition := p_part_name;

        END LOOP;


     END LOOP;

    DBMS_OUTPUT.PUT_LINE(chr(10) || lpad('=',66, '=') );
    DBMS_OUTPUT.PUT_LINE ('Exiting ......'|| TO_CHAR(sysdate, 'Mon DD YYYY HH:MI AM' ) );
END;
/
exit
EOF

ERRORCOUNT=`egrep -i 'ora-' ${JOB_SQL_LOG}|wc -l`
echo "ErrorCount : "$ERRORCOUNT
if [ $ERRORCOUNT -gt 0 ]
then
       cat ${JOB_SQL_LOG} 
       FAILURE_UPDATE ;
       FAIL_MAIL $JOB_SQL_LOG
       exit 1
else
       SUCCESS_UPDATE ;
       SUCCESS_MAIL $JOB_SQL_LOG
fi

# ::::::::::::::::::::::::::::::: END ::::::::::::::::::::::::::::::::::::::::::
