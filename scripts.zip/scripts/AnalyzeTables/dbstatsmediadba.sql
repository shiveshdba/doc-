/*
exec run_dm_tabstats;
*/
exec dbms_stats.gather_schema_stats('MEDIADBA',cascade=>true);

