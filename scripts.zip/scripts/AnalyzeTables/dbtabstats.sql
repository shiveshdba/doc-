spool /home/oracle/gather_stats_stgdba.log
Set timing on
Set echo on
select name, open_mode from v$database;
exec dbms_stats.gather_schema_stats('STGDBA',cascade=>true);
set timing off
set echo off
