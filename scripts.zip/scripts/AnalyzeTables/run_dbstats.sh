#!/bin/sh
#  This script invokes rman to perform db backups to disk
#
#
ORACLE_BASE=/vol01/app/oracle; export ORACLE_BASE
ORACLE_HOME=$ORACLE_BASE/product/db/12.2.0.1; export ORACLE_HOME

SCRIPTDIR=/vol01/app/oracle/admin/scripts/AnalyzeTables; export SCRIPTDIR
LOGDIR=/home/oracle/bin/log; export LOGDIR
LOGDATE=`date '+%y%m%d'`; export LOGDATE
LOGNAME=/dbstats_log.$LOGDATE; export LOGNAME
ORAPASS=`cat ${SCRIPTDIR}/orapass_mediadba`; export ORAPASS
echo "weekly DM stats job initiated on `date '+%D %T'` " >>$LOGDIR$LOGNAME
execsql_runstats()
{
(echo "$ORAPASS";
sleep 5;
cat <<EOF!
START $SCRIPTDIR/dbstatsmediadba.sql
/
EOF!
) | $ORACLE_HOME/bin/sqlplus mediadba@DEAL > /tmp/dbstats_$$$$
CHKRESULT=`cat /tmp/dbstats_$$$$ | grep -c  'ORA-'`
if [ $CHKRESULT = 0 ]
then
echo "this run successful at `date '+%D %T'` " >>$LOGDIR$LOGNAME
	echo "this run successful at " >>$LOGDIR$LOGNAME
else 
	echo ' run failed ... check log ' >> /tmp/dbstats_$$$$
	cat /tmp/dbstats_$$$$ >>$LOGDIR$LOGNAME
fi
}
execsql_runstats

exit 0
