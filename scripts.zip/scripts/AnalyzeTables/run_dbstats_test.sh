#!/bin/sh
#  This script invokes rman to perform db backups to disk
#
#
ORACLE_BASE=/vol01/app/oracle; export ORACLE_BASE
ORACLE_HOME=$ORACLE_BASE/product/db/12.2.0.1 export ORACLE_HOME
ORACLE_SID=DEAL export ORACLE_SID
PATH=$ORACLE_HOME/bin:$PATH  export PATH
LD_LIBRARY_PATH=$ORACLE_HOME/lib:/lib:/usr/lib export LD_LIBRARY_PATH
CLASSPATH=$ORACLE_HOME/jlib:$ORACLE_HOME/rdbms/jlib export CLASSPATH

SCRIPTDIR=/vol01/app/oracle/admin/scripts/AnalyzeTables; export SCRIPTDIR
LOGDIR=/home/oracle/bin/log; export LOGDIR
LOGDATE=`date '+%y%m%d'`; export LOGDATE
#LOGNAME=/dbstats_log.$LOGDATE; export LOGNAME
#ORAPASS=`cat ${SCRIPTDIR}/orapass_mediadba`; export ORAPASS
echo "JOb started at `date '+%y%m%d'`"
sqlplus / as sysdba @/vol01/app/oracle/admin/scripts/AnalyzeTables/dbtabstats.sql
exit
