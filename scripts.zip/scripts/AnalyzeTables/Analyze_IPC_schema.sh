#!/bin/sh
date
export ORACLE_HOSTNAME=nj4-gen-porc4.utg.uvn.net
export ORACLE_BASE=/vol01/app/oracle
export ORACLE_HOME=$ORACLE_BASE/product/db/11.2.0.4
export ORACLE_SID=INFPRD
export PATH=/usr/sbin:$PATH
export PATH=$ORACLE_HOME/bin:$PATH
export LD_LIBRARY_PATH=$ORACLE_HOME/lib:/lib:/usr/lib
export CLASSPATH=$ORACLE_HOME/jlib:$ORACLE_HOME/rdbms/jlib

sqlplus -s /nolog <<-EOF >> /tmp/Analyze_${ORACLE_SID}.log
connect / as sysdba

column host_name     format A15 Head 'Host'
column instance_name format A10 Head 'Database'
column RunDate       format A22

SELECT SUBSTR(host_name,1, INSTR(host_name, '.', 1)-1) host_name,  instance_name, TO_CHAR(sysdate, 'Mon DD YYYY HH:MI AM') RunDate FROM v\$instance;

exec DBMS_OUTPUT.PUT_LINE ('Analyzing Schema: IPC');
exec DBMS_STATS.GATHER_SCHEMA_STATS (ownname => 'IPC', method_opt => 'FOR ALL COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_OUTPUT.PUT_LINE ('Exiting ......');

SELECT SUBSTR(host_name,1, INSTR(host_name, '.', 1)-1) host_name,  instance_name, TO_CHAR(sysdate, 'Mon DD YYYY HH:MI AM') RunDate FROM v\$instance;

exit
date
EOF

# ::::::::::::::::::::::::::::::: END ::::::::::::::::::::::::::::::::::::::::::

