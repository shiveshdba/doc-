#!/bin/ksh
#
#set -x
# ---------------------------------------------------------------------------
if [ $# -ne 1 ]
then
    print "Usage: $0 <db name>"
    exit
fi
. /home/oradba/profile/.profile-$1
. /home/oradba/scripts/rman_env_$1.sh

set -x

PATH=$PATH:/bin
export PATH

ORACLE_SID=$1
export ORACLE_SID
LOG_DIR=/home/oradba/scripts/archlog_backup/log
export LOG_DIR
SCR_DIR=/home/oradba/scripts/archlog_backup
export SCR_DIR
LOG_FILE=$LOG_DIR/${ORACLE_SID}_archivelog_backup.sh.out
export LOG_FILE
SUM_FILE=$SCR_DIR/archivelog_backup_summary
export SUM_FILE
ARCH_DIR=$ARCH_DIR
export ARCH_DIR
SAVED_DIR=$SAVED_DIR
export SAVED_DIR
R_SAVED_DIR=$R_SAVED_DIR
export R_SAVED_DIR
R_SAVED_RETENTION=$R_SAVED_RETENTION
SAVED_RETENTION=$SAVED_RETENTION
ARCH_RETENTION=$ARCH_RETENTION
export R_SAVED_RETENTION SAVED_RETENTION ARCH_RETENTION

R_SAVED_DAYS=`expr $R_SAVED_RETENTION + 1`
SAVED_DAYS=`expr $SAVED_RETENTION + 1`
ARCH_DAYS=`expr $ARCH_RETENTION + 1`
export R_SAVED_DAYS SAVED_DAYS ARCH_DAYS

#EMAILREC="c.lakkinani-iga@univision.net"
#FAILREC="c.lakkinani-iga@univision.net"

EMAILREC="ETSDBSOracleServerSupport@univision.net"
FAILREC="ETSDBSOracleServerSupport@univision.net"

export EMAILREC
export FAILREC


##################################################
# Check if the Last run of the program still running : #
##################################################

#JOBID=`ps -ef | grep 'archivelog_backup.sh' | grep $ORACLE_SID | grep -v grep `
#JOBID=`pgrep -fl "archivelog_backup.sh .* $ORACLE_SID"`

LOCKFILE="${SCR_DIR}/archivelog_backup_${ORACLE_SID}.lock"
echo "LOCKFILE : ${LOCKFILE}" >> $JOB_LOG

echo $LOCKFILE

if test -f "${LOCKFILE}"
then
    echo "Last execution of the program still running " > /tmp/archivelog_backup_running.out
    echo "ERROR: archivelog_backup already running  on `hostname` at `date +%Y-%m-%d-%H%M`" >> $SUM_FILE
    echo "ERROR: archivelog_backup already running  on `hostname` at `date +%Y-%m-%d-%H%M`"
    cat /tmp/archivelog_backup_running.out
    /usr/bin/mailx -s "${ORACLE_SID} Archived Log backup last execution still running" ${EMAILREC} </tmp/archivelog_backup_running.out
    exit 2
fi

echo $Dt > ${LOCKFILE}

# ---------------------------------------------------------------------------
# You may want to delete the output file so that backup information does
# not accumulate.  If not, delete the following lines.
# ---------------------------------------------------------------------------

if [ -f "$LOG_FILE" ]
then
        rm -f "$LOG_FILE"
fi

# ---------------------------------------------------------------------------
# Log the start of this script.
# ---------------------------------------------------------------------------

echo Script $0 > $LOG_FILE
echo ==== started on `date` ==== >> $LOG_FILE
echo >> $LOG_FILE
chmod 666 $LOG_FILE

# ---------------------------------------------------------------------------
# Print out the value of the variables set by this script.
# ---------------------------------------------------------------------------

echo >> $LOG_FILE
echo   "ORACLE_SID: $ORACLE_SID" >> $LOG_FILE
echo >> $LOG_FILE


##################################################
# Cleanup the old backup dump in the directory : #
##################################################

echo "Total disk space size" >> $LOG_FILE
df -k $SAVED_DIR >> $LOG_FILE
echo "" >> $LOG_FILE

echo "Following files will be deleted " >> $LOG_FILE
echo "Archived log retention   : $ARCH_DAYS days " >> $LOG_FILE
echo "Saved directory retention: $SAVED_DAYS days " >> $LOG_FILE
echo "NFS directory retention  : $R_SAVED_DAYS days " >> $LOG_FILE

/usr/bin/find ${ARCH_DIR} -name "log1_*.arc" -type f -mtime +$ARCH_RETENTION -print >> $LOG_FILE
/usr/bin/find ${SAVED_DIR} -name "log1_*.Z" -type f -mtime +$SAVED_RETENTION -print >> $LOG_FILE
/usr/bin/find ${R_SAVED_DIR} -name "log1_*.Z" -type f -mtime +$R_SAVED_RETENTION -print >> $LOG_FILE

/usr/bin/find ${ARCH_DIR} -name "log1_*.arc" -type f -mtime +$ARCH_RETENTION -exec /bin/rm -f {} \;
/usr/bin/find ${SAVED_DIR} -name "log1_*.Z" -type f -mtime +$SAVED_RETENTION -exec /bin/rm -f {} \;
/usr/bin/find ${R_SAVED_DIR} -name "log1_*.Z" -type f -mtime +$R_SAVED_RETENTION -exec /bin/rm -f {} \;


echo "" >> $LOG_FILE

set -x
##################################################
# Get the latest archivelog number from database: #
##################################################

$ORACLE_HOME/bin/sqlplus /nolog <<EOF >> $LOG_FILE
@${SCR_DIR}/${ORACLE_SID}_get_latest_log.sql
EOF

LATESTLOG=`cat /tmp/${ORACLE_SID}_latest_log.out | grep [0-9] `
export LATESTLOG
LATESTLOG=`expr $LATESTLOG + 0 `
export LATESTLOG
echo "latest log number is $LATESTLOG  \n " >> $LOG_FILE
echo "arch dir  is $ARCH_DIR  \n " >> $LOG_FILE
echo "saved dir is $SAVED_DIR  \n " >> $LOG_FILE

##################################################
# Save the archivelogs to SAVED_DIR : #
##################################################

for LOGNUM in `find ${ARCH_DIR} ! -newer ${ARCH_DIR}/log1_${LATESTLOG}_* -a -type f -print | grep -v 'arc.Z' | while read a;do echo $(basename $a);done | sort `
do
  echo "Checking $LOGNUM"
  echo "LOGNUM is $LOGNUM  \n " >> $LOG_FILE
  if [ ! -f "${SAVED_DIR}/${LOGNUM}.Z" ]
  then
      echo "Now copying and compressing $LOGNUM \n" >> $LOG_FILE
      cp ${ARCH_DIR}/$LOGNUM  ${SAVED_DIR}/
      compress ${SAVED_DIR}/$LOGNUM
      SAVED_STAT=$?
      if [ "$SAVED_STAT" != "0" ]
      then
          echo "Copy and compress to SAVED_DIR failed...exiting at `date`" >> $LOG_FILE
          echo "ERROR: archivelog_backup failed on `hostname` at `date +%Y-%m-%d-%H%M`" >> $SUM_FILE
          echo "ERROR: archivelog_backup failed on `hostname` at `date +%Y-%m-%d-%H%M`"
          cp -p "$LOG_FILE" "$LOG_FILE.`date +%Y-%m-%d-%H%M`"
          /usr/bin/mailx -s "${ORACLE_SID} Archived Log backup: Failed" ${FAILREC} <${LOG_FILE}
          rm ${LOCKFILE}
          exit 1
      fi
  else
#      echo "Compressed file $LOGNUM already exists" >> $LOG_FILE
      echo "Compressed file $LOGNUM already exists"
  fi
done

# Uncomment beow for debugging only. Suffice to send one success email at the end
#if [ "$SAVED_STAT" = "0" ]
#then
#/usr/bin/mailx -s "${ORACLE_SID}:Archived Log backup Completed successfully" ${EMAILREC} <${LOG_FILE}
#fi

echo "rsynching the archivelog backups to NFS" >> $LOG_FILE

rsync -tv $SAVED_DIR/* $R_SAVED_DIR/ >> $LOG_FILE
RSTAT=$?

if [ "$RSTAT" = "0" ]
then
    echo "SUCCESS: archivelog_backup successful on `hostname` at `date +%Y-%m-%d-%H%M`" >> $SUM_FILE
    echo "SUCCESS: archivelog_backup successful on `hostname` at `date +%Y-%m-%d-%H%M`"
    LOGMSG="rsync completed successfully"
    echo ==== $LOGMSG ==== >> $LOG_FILE
    echo ==== Ended on `date` ==== >> $LOG_FILE
    /usr/bin/mailx -s "${ORACLE_SID} Archived Log backup: Completed successfully" ${EMAILREC} <${LOG_FILE}
else
    echo "ERROR: archivelog_backup failed on `hostname` at `date +%Y-%m-%d-%H%M`" >> $SUM_FILE
    echo "ERROR: archivelog_backup failed on `hostname` at `date +%Y-%m-%d-%H%M`"
    LOGMSG="rsync failed. ended in error"
    echo ==== $LOGMSG ==== >> $LOG_FILE
    echo ==== Ended on `date` ==== >> $LOG_FILE
    /usr/bin/mailx -s "${ORACLE_SID} Archived Log backup: Failed" ${FAILREC} <${LOG_FILE}
fi
echo $LOGMSG

##################################################
# Cleanup older RMAN log files :                 #
##################################################

cp -p "$LOG_FILE" "$LOG_FILE.`date +%Y-%m-%d-%H%M`"
/usr/bin/find $LOG_DIR -name '*.sh.out.*' -mtime +15 -exec /bin/rm {} \;
rm ${LOCKFILE}
exit $RSTAT

