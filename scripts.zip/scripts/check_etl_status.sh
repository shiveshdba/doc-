#!/bin/sh
#set -x
#
#
# Script to check status of BI_ETL. If it has failed, send an e-mail.
#
# Read in Oracle's environment. (ORACLE_HOME, ORACLE_BASE, etc.)

#. $HOME/.bash_profile_INVBIP
. /home/oracle/oraINVBIP
ORACLE_HOME=/vol01/app/oracle/product/db/12.2.0.1
export ORACLE_HOME

EMAILREC="DealmakerSupport@univision.net, ETSDBSOracleServerSupport@univision.net"

ORADBA_DIR=/vol01/app/oracle/admin/scripts
export ORADBA_DIR
LOGFILE=/vol01/app/oracle/admin/scripts/bi_etl.log
export LOGFILE

# Reset to the new ORACLE_SID.
ORACLE_SID=INVBIP
export ORACLE_SID

NLS_DATE_FORMAT='MON-DD-YY HH24:MI:SS'
export NLS_DATE_FORMAT
echo "Start of BI_ETL check status " > $LOGFILE

END_DATE=`sqlplus -silent bidba/bidba@invbip <<END
set pagesize 0 feedback off verify off heading off echo off
select end_date from bidba.audit_etl_history
where to_char(run_date, 'MM-DD-YYYY') = to_char(sysdate, 'MM-DD-YYYY');

exit
END`
echo "$END_DATE ---  This is the end_date" >> $LOGFILE

if [ -z "$END_DATE" ]; then
   /bin/mailx -s "Dealmaker Production - BI ETL $END_DATE Issue" $EMAILREC < /vol01/app/oracle/admin/scripts/etl_fail.txt
   echo "$ORACLE_SID:  BI_ETL FAILED" >>$LOGFILE
else
  /bin/mailx -s "Dealmaker Production - BI ETL $END_DATE COMPLETED " $EMAILREC < /vol01/app/oracle/admin/scripts/etl_success.txt
  echo "$ORACLE_SID: BI_ETL SUCCESS" >>$LOGFILE

fi

exit 0
