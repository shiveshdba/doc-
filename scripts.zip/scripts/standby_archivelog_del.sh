#!/bin/bash
########################################################################
help="
  Name:    standby_archivelog_del.sh

  Purpose: For each DR instance listed in the ORATAB file, try to login;
           if successful, report all the archivelog(s) applied before sysdate-1
           and hence making the candidate for deletion deletion from disk
           ; thereby will be deleted. 
          

  Usage:  standby_archivelog_del.sh 
"
# 
#
#
#         
#        
#
# ----------------------------------------------------------------------
# REVISION HISTORY       ** PLEASE KEEP MOST RECENT FIRST **
#
# REV    DATE     BY               DESCRIPTION
# --- ---------- -------------    -----------
# 000	29-Dec-16 Shivesh Mishra  Initial Release
########################################################################
#
#
#----------------------------------------------------------------------
# Check for options
#----------------------------------------------------------------------
#
echo "----------------------------------------------------------------"
##########-----Defining Varliables----------------------#############################
#------------------------
#. /home/oracle/.bash_profile
ORACLE_BASE=/vol01/app/oracle
export ORACLE_BASE  
NLS_LANG=_.WE8ISO8859P1
ORATAB=/etc/oratab
export ORATAB
################## Starting BODY ###############################################
#
#grep "^[^#*][^:]*:[^:][^:]*:[YyNn]" $ORATAB | cut -d : -f 1 | tee /home/oracle/shivesh/tns_db.par
exec 1>/vol01/app/oracle/admin/scripts/check_`date +%Y%m%d`.log
cd /home/oracle
a=0
while read line
do
if [ -n "$line" ] ; then
        #echo $line
        TNS=`echo $line`
echo "DB Name: "$TNS
VAR1=`echo $line | cut -d',' -f1`
ORACLE_SID=$VAR1
VAR2=`echo $line | cut -d',' -f2`
echo $VAR1
echo $VAR2
if [ "$VAR2" -eq 1 ];
then
ORACLE_HOME=/vol01/app/oracle/product/db/11.2.0.4
export ORACLE_HOME
LD_LIBRARY_PATH=$ORACLE_HOME/lib:$LD_LIBRARY_PATH
PATH=$ORACLE_HOME/bin:$PATH
export NLS_LANG LD_LIBRARY_PATH PATH
export ORATAB
TNS_ADMIN=$ORACLE_HOME/network/admin
export TNS_ADMIN
export ORACLE_SID
else
ORACLE_HOME=/vol01/app/oracle/product/db/12.2.0.1
export ORACLE_BASE ORACLE_HOME
NLS_LANG=_.WE8ISO8859P1
LD_LIBRARY_PATH=$ORACLE_HOME/lib:$LD_LIBRARY_PATH
PATH=$ORACLE_HOME/bin:$PATH
export NLS_LANG LD_LIBRARY_PATH PATH
TNS_ADMIN=$ORACLE_HOME/network/admin
export TNS_ADMIN
export ORACLE_SID
fi
##################################### Checkpoint ################################################
#
test= . /vol01/app/oracle/admin/scripts/sql_check.sh
if [ -n "$test"] ; 	
then
echo "====================== Connected to $ORACLE_SID RMAN==============================="
rman target / <<EOF
crosscheck archivelog all;
delete force noprompt  archivelog until time 'sysdate-1';
crosscheck archivelog all;
EOF
else
exit
 fi 
	fi
		
a=`expr $a + 1`
echo "========================================================================"
echo "=====DB $a completed for $line=============================="
echo "======================================================================="
done < /vol01/app/oracle/admin/scripts/tns_db.par
#
##################### Send logfile ###############################################
#
echo "Please check attached log and review it." | mailx -s "Archivelog has been cleared on DR instance@fl1-gen-rorc4" -a "/vol01/app/oracle/admin/scripts/check_`date +%Y%m%d`.log" -c LEjjaki@us.univision.com -c crahner@UNIVISION.NET -c aiaz.muzzammill@capgemini.com ETSDBSOracleServerSupport@univision.net
#echo "Please check attached log and review it." | mailx -s "Archivelog has been cleared on DR instance@fl1-gen-rorc6" -a "/vol01/app/oracle/admin/scripts/check_`date +%Y%m%d`.log" -c hgowder-iga@UNIVISION.NET -c ndurairaj-iga@UNIVISION.NET
#
# Delete old logfiles
/usr/bin/find /vol01/app/oracle/admin/scripts -name \*.log -mtime +1 -exec rm {} \;
