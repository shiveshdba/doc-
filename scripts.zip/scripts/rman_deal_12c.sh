#!/bin/sh
#set -x
#
# rman_driver.sh
#
# Script to perform Oracle Recover Manager (RMAN) backups of Oracle databases.
#
# Usage:
#    rman_driver.sh [level [SID]]
#
#    level:     The dump level.  Default: 0
#    SID:       The Oracle instance to be backed-up.  Default: $ORACLE_SID
#
# removed deletion of archive logs

#
# Read in Oracle's environment. (ORACLE_HOME, ORACLE_BASE, etc.)
#  R  E  V  I  S  I  O  N    H  I  S  T  O  R  Y
#
# 10-07-2013  Lorna Scully, changed from 6 channels to 3 channels
#

. /home/oracle/oraDEAL
ORACLE_HOME=/vol01/app/oracle/product/db/12.2.0.1
export ORACLE_HOME

EMAILREC="ETSDBSOracleServerSupport@univision.net"
#EMAILREC="hgowder-iga@UNIVISION.NET"

ORADBA_DIR=/vol01/app/oracle/admin/scripts
export ORADBA_DIR

# Configure the backup level.
if [ "x$1" = "x" ]; then
        LEVEL=0
else
        LEVEL=$1
fi
export LEVEL

# Check for the SID.
if [ "x$2" = "x" ] && [ "x$ORACLE_SID" = "x" ]; then
        echo ERROR: ORACLE_SID not specified.
        echo Usage: $0 [level [SID]]
        exit 1
fi

# Save the current ORACLE_SID, if any.
OLD_ORACLE_SID=$ORACLE_SID

# Reset to the new ORACLE_SID.
ORACLE_SID=$2
export ORACLE_SID

# Check for the instance configuration file.
if [ ! -f ${ORADBA_DIR}/rman_env_${ORACLE_SID}.sh ]; then
        echo ERROR: Could not locate rman_env_${ORACLE_SID}.sh configuration file.
        exit 1
fi

# Load in the configuration file.
#echo Loading configuration file rman_env_${ORACLE_SID}.sh
. ${ORADBA_DIR}/rman_env_${ORACLE_SID}.sh

# Make the backup directory to hold today's backup if it does not exist.
CUR_DIR="$BACKUP_DIR/$ORACLE_SID/RMANDB-`date '+%Y%m%d-%H%M%S'`-${LEVEL}"

#echo Creating backup directory $CUR_DIR
if [ ! -d $CUR_DIR ]; then
        mkdir $CUR_DIR
fi
chgrp oinstall $CUR_DIR
chmod 775 $CUR_DIR
LOGFILE=$CUR_DIR/rman-${ORACLE_SID}-`date +'%m%d%y'`.log

NLS_DATE_FORMAT='MON-DD-YY HH24:MI:SS'
export NLS_DATE_FORMAT

BS_TIME=`sqlplus -silent savvis/$SAVVIS_PWD <<END
set pagesize 0 feedback off verify off heading off echo off
  select '"to_date('''||to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||''',''yyyy-mm-dd hh24:mi:ss'')"' from dual;
exit
END`

## Replace rman script in the catalog
#echo replace script ${ORACLE_SID}_db > cr_script.txt
#echo "{allocate channel d1 type disk;" >> cr_script.txt
#echo "backup incremental level ${LEVEL} filesperset 1" >> cr_script.txt
#echo "(database format '${CUR_DIR}/bk_%s_%p_%t');" >> cr_script.txt
#echo "BACKUP FORMAT '${CUR_DIR}/cntrl_%s_%p_%t' (CURRENT CONTROLFILE channel d1);" >> cr_script.txt
#echo "sql 'alter system archive log current';" >> cr_script.txt
#echo "backup format '${CUR_DIR}/arc_%s_%p_%t' (archivelog from time ${BS_TIME} until time 'sysdate' channel d1 );" >> cr_script.txt
#echo "release channel d1;" >> cr_script.txt
#echo "}" >> cr_script.txt
##

## Starting backup
echo "$ORACLE_SID: RMAN backup taking off on `date +'%m%d%y'` at `date +'%H%M%S'`" |tee -a $LOGFILE
echo " " >> $LOGFILE

#rman nocatalog << EOF
( rman nocatalog <<EOF
@$ORADBA_DIR/connect${ORACLE_SID}.rman

## Changed to add rman catalog
##( $ORACLE_HOME/bin/rman target / <<EOF
configure controlfile autobackup format for device type disk to '${CUR_DIR}/%F';
configure controlfile autobackup ON;

sql 'alter system archive log current';
run { allocate channel ch1 type disk maxopenfiles 1;
      allocate channel ch2 type disk maxopenfiles 1;
      allocate channel ch3 type disk maxopenfiles 1;
#      allocate channel ch4 type disk maxopenfiles 1;
#      allocate channel ch5 type disk maxopenfiles 1;
#      allocate channel ch6 type disk maxopenfiles 1;
      #This part was added by Larbi, Univision Online. 08/16/2006
        #set limit channel ch1 kbytes=41943040;
        #set limit channel ch2 kbytes=41943040;
        #set limit channel ch3 kbytes=41943040;
        #set limit channel ch4 kbytes=41943040;
        #set limit channel ch5 kbytes=41943040;
        #set limit channel ch6 kbytes=41943040;

        backup incremental level ${LEVEL} filesperset 1 (database format '${CUR_DIR}/bk_%s_%p_%t');

        #sql 'ALTER SYSTEM SWITCH LOGFILE';
      BACKUP FORMAT '${CUR_DIR}/cntrl_%s_%p_%t' (CURRENT CONTROLFILE channel ch1);
        sql 'alter system archive log current';
      backup format '${CUR_DIR}/arc_%s_%p_%t' (archivelog from time ${BS_TIME} until time 'sysdate' channel ch1 );
        release channel ch1;
        release channel ch2;
        release channel ch3;
#       release channel ch4;
#       release channel ch5;
#       release channel ch6;
    }
configure controlfile autobackup format for device type disk to '${BACKUP_DIR}/${ORACLE_SID}/%F';


#Purge old backup files as per retention period

CROSSCHECK BACKUP;
DELETE NOPROMPT OBSOLETE  RECOVERY WINDOW OF ${DBF_BKUP_RETENTION} days;
EOF

) | tee -a $LOGFILE

if [ $? -ne 0 ] || [ `egrep -i 'ora-|error|failure' $LOGFILE |wc -l` -ne 0 ] ; then
echo "$ORACLE_SID DD RMAN ${LEVEL}: FAILED"

/bin/mailx -s "$ORACLE_SID DD RMAN ${LEVEL}: FAILED" ETSDBSOracleServerSupport@univision.net < $LOGFILE
#/bin/mailx -s "$ORACLE_SID DD RMAN ${LEVEL}: FAILED" $EMAILREC < $LOGFILE

exit
fi

echo " " >> $LOGFILE
echo "$ORACLE_SID: RMAN backup ending on `date +'%m%d%y'` at `date +'%H%M%S'`" |tee -a $LOGFILE
echo " " >> $LOGFILE

echo " "  >> $LOGFILE
echo "List of backup files:" >> $LOGFILE
echo "=====================" >> $LOGFILE
ls -lrt  $CUR_DIR/*          >> $LOGFILE

#OK everything finished.
/bin/mailx -s "$ORACLE_SID DD RMAN ${LEVEL}: completed successfully." $EMAILREC < $LOGFILE
echo "$ORACLE_SID DD RMAN ${LEVEL}: completed successfully."

# Reset ORACLE_SID to OLD_ORACLE_SID
if [ "x$OLD_ORACLE_SID" = "x" ]; then
        ORACLE_SID=""
else
        ORACLE_SID=$OLD_ORACLE_SID
        export ORACLE_SID
fi

exit 0

