#!/bin/sh
#
#
# The following variables are used by rman_driver.sh
#
# BACKUP_DIR
# Description:  This is the location of the directory where rman_driver.sh will
#output its files.
# There must be enough space on this partition in order to accommodate for all t
#he backup files.
# If there is not, rman_driver.sh will fail.
# Possible values:  any valid UNIX directory.
# Example:  BACKUP_DIR=/export/oracle/backup
#
# LOG_DIR
# Description:  Location of the log file for this instance.  The file is named a
#fter the instance.
# Possible values:  any valid UNIX directory.
ARCH_DIR=/maestroprd-03/arch/MAESTROPRD
SAVED_DIR=
R_SAVED_DIR=
BACKUP_DIR=/app/mia-miadb/oracle/fl1-mae-porcl1
#BACKUP_DIR=/app/nj-dd01/remote/oracle
RETENTION=1
ARCH_RETENTION=0
SAVED_RETENTION=2
R_SAVED_RETENTION=7
ARC1_DIR=/maestroprd-03/arch/MAESTROPRD
ORADBA_PWD=uim30vol
ORADBA_DIR=/vol01/app/oracle/admin/scripts
STATSPACK_UID=perfstat/p0rfst3t
SYSRMANPASS=sysrman_475p
RMANCATPASS=oemrep1
export BACKUP_DIR ARC1_DIR ORADBA_PWD SAVED_DIR R_SAVED_DIR STATSPACK_UID RETENTION SAVED_RETENTION R_SAVED_RETENTION ORADBA_DIR
