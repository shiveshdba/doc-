#!/bin/sh
#
#
# The following variables are used by rman_driver.sh
#
# BACKUP_DIR
# Description:  This is the location of the directory where rman_driver.sh will
#output its files.
# There must be enough space on this partition in order to accommodate for all t
#he backup files.
# If there is not, rman_driver.sh will fail.
# Possible values:  any valid UNIX directory.
# Example:  BACKUP_DIR=/export/oracle/backup
#
# LOG_DIR
# Description:  Location of the log file for this instance.  The file is named a
#fter the instance.
# Possible values:  any valid UNIX directory.

#ARCH_DIR=/u02/arch/DEAL
#SAVED_DIR=
#R_SAVED_DIR=
#BACKUP_DIR=/app/nj-njdb/oracle
#RETENTION=1
#ARCH_RETENTION=0
#SAVED_RETENTION=2
#R_SAVED_RETENTION=7
#ARC1_DIR=/u02/arch/DEAL
#ORADBA_PWD=uim30vol
#ORADBA_DIR=/home/oradba/scripts
#STATSPACK_UID=perfstat/p0rfst3t
SYSRMANPASS=sysrman_475p
#RMANCATPASS=oemrep1

export ORACLE_BASE=/vol01/app/oracle
export ORACLE_HOME=/vol01/app/oracle/product/db/12.2.0.1
export ORACLE_SID=INVBIP
export PATH=$PATH:$ORACLE_HOME/bin
export ARCH_DIR=/invbip-03/arch
export BACKUP_DIR=/app/mia-miadb/oracle/fl1-invbip-porcl3
export RETENTION=1
export ARCH_RETENTION=0
export SAVED_RETENTION=2
export R_SAVED_RETENTION=7
export ORADBA_DIR=/v0l01/app/oracle/admin/scripts
export LD_LIBRARY_PATH=$ORACLE_HOME/lib
export DBF_BKUP_RETENTION=14
export SAVVIS_PWD=svvs123
export SAVVIS_DIR=/v0l01/app/oracle/admin/scripts
#SCRIPTHOME=/home/oradba/bin; export SCRIPTHOME
#SCRIPTDIR=/home/oradba/scripts; export SCRIPTDIR
#LOGDIR=/home/oradba/scripts/log; export LOGDIR
LOGDATE=`date '+%y%m%d'`; export LOGDATE

export BACKUP_DIR ARC1_DIR ORADBA_PWD SAVED_DIR R_SAVED_DIR STATSPACK_UID RETENTION SAVED_RETENTION R_SAVED_RETENTION ORADBA_DIR
