echo -e " \033[0;100m \033[1;97m ####################### `date` ################################## ";tput sgr0
echo -e "\n\n\n\n"

#!THIS BLOCK WILL TAKE THE CONFIRMATION FROM USER WHETHER ALL PRE-REQUISITES HAVE BEEN INSTALLED
while :
do

echo -e " \033[0;100m \033[1;97m  Have you checked ASM Disks have been created with correct privileges(check Major & Minor number) and configured multipathing/udev configured to present the ASM devices ?";tput sgr0

echo -e "\n\n"

while true
do
    echo -e "\033[0;100m \033[1;97m";read -p "Do you want to proceed (y/n) : " PROCEED;tput sgr0
    case "$PROCEED" in
      n|N) echo -e " \e[1;91m  ASM Disks has not  been created with correct Major & Minor Number/multipathing/udev has not been configured correctly to present the ASM devices. 12c(12.1.0.5) grid infrastructure installation and ASM configuration cancelled!!";tput sgr0
           echo -e "\n\n\n";
           exit -1;;
      y|Y) echo -e "  \033[0;100m \033[1;97m Have you configured SSH between grid to oracle User?";tput sgr0
           echo -e "\n\n\n\n";
           break;;
      *) echo -e " \e[1;91m Response not valid";tput sgr0
         echo -e "\n\n\n\n";;
    esac
done

echo -e "\n\n"

while true
do
    echo -e "\033[0;100m \033[1;97m";read -p "Do you want to proceed (y/n) : " PROCEED;tput sgr0
    case "$PROCEED" in
      n|N) echo -e " \e[1;91m  SSH has not been configured from grid to oracle user. 12c(12.1.0.5) grid infrastructure installation and ASM configuration cancelled!!";tput sgr0
           echo -e "\n\n\n";
           exit -1;;
      y|Y) echo -e "  \033[0;100m \033[1;97m Have you configured sudo privileges to run OrainstRoot.sh, root.sh and roothas.pl from grid and Oracle user(execute "sudo -l" from oracle & grid user to see what are the sudo privileges configured for that user)?";tput sgr0
           echo -e "\n\n\n\n";
           break;;
      *) echo -e " \e[1;91m Response not valid";tput sgr0
         echo -e "\n\n\n\n";;
    esac
done


while true
do
    echo -e "\033[0;100m \033[1;97m";read -p "Do you want to proceed (y/n) : " PROCEED;tput sgr0
    case "$PROCEED" in
      n|N) echo -e " \e[1;91m  12c(grid_x.tgz)Grid infrastructure software has not been placed on the New Database Server. 12c(12.1.0)Grid infrastructure software and ASM configuration  Cancelled \n\n\n\n";tput sgr0
           exit -1;;
      y|Y) echo -e " \033[0;100m \033[1;97m Have you copied the 12c(grid_x.tgz)Grid infrastructure software on New Database Server?";tput sgr0
           echo -e "\n\n\n\n"
           break;;
      *) echo -e " \e[1;91m Response not valid ";tput sgr0
         echo -e "\n\n\n\n";
    esac
done


while true
do
    echo -e "\033[0;100m \033[1;97m";read -p "Do you want to proceed (y/n) : " PROCEED;tput sgr0
    case "$PROCEED" in
      n|N) echo -e " \e[1;91m  12c(db_x.tgz)Oracle Database software has not been placed on New Database Server. 12c(12.1.0)Grid infrastructure software and ASM configuration Cancelled";tput sgr0
           echo -e "\n\n\n\n";
           exit -1;;
      y|Y) echo -e " \033[0;100m \033[1;97m Have you copied the 12c(db_x.tgz)Oracle Database software on New Database Server?";tput sgr0
           echo -e "\n\n\n\n";
           break;;
      *) echo -e " \e[1;91m Response not valid";tput sgr0
         echo -e "\n\n\n\n";;
    esac
done

echo -e " \033[0;100m \033[1;97m If Yes, Installation Proceeds else installation restarts, and please verify above pre-requisites before retry ";tput sgr0

echo -e "\n\n\n\n"


while true
do
    echo -e "\033[0;100m \033[1;97m";read -p "Do you want to proceed (y/n) : " PROCEED;tput sgr0
    case "$PROCEED" in
      n|N) echo -e " \e[1;91m Some of the pre-requisies for 12c(12.1.0)Grid infrastructure software and ASM configuration has not yet comfigured. 12c(12.1.0)Grid infrastructure software installaion wizard restarted .. ";tput sgr0
           echo -e "\n\n\n\n";
           break;;
      y|Y) echo -e " \033[0;100m \033[1;97m Proceeding with 12c(12.1.0)Grid infrastructure software configuration  & Database Creation";tput sgr0
           echo -e "\n\n\n\n";
           break 2;;
      *) echo -e " \e[1;91m Response not valid \n\n\n\n";tput sgr0
         echo -e "\n\n\n\n"
    esac
done
done
################################################################################################################################################################

#!THIS BLOCK WILL PROMPT TO CHOOSE THE DATABSE TEMPLATE(SMALL,MEDIUM OR LARGE) FROM BELOW MENU OPTION

 
while :
do
 clear
 echo -e " \033[0;100m \033[1;97m  M A I N - M E N U";tput sgr0
 echo -e " \033[0;100m \033[1;97m 1. Small Database";tput sgr0
 echo -e " \033[0;100m \033[1;97m 2. Medium Database";tput sgr0
 echo -e " \033[0;100m \033[1;97m 3. Large Database";tput sgr0
 echo -e " \033[0;100m \033[1;97m 4. Exit";tput sgr0
 echo -en " \033[0;100m \033[1;97m Please enter option [1 - 4]";tput sgr0
 read opt
 case $opt in
  1) echo -e " \033[0;100m \033[1;97m ************ Opted for Small Database ************* ";tput sgr0
     echo -e "\n\n"
     TEMPLATE=Tesco12cSmallTemplate.dbt
     break;;
  2) echo -e " \033[0;100m \033[1;97m ************ Opted for Medium Database ************* ";tput sgr0
     echo -e "\n\n"
     TEMPLATE=Tesco12cMediumTemplate.dbt
     break;;
  3) echo -e " \033[0;100m \033[1;97m ************ Opted for Large Database ************* ";tput sgr0
     echo -e "\n\n"
     TEMPLATE=Tesco12cLargeTemplate.dbt
     break;;
  4) echo -e " \033[0;90m \033[1;94m Exiting 12c(12.1.0)Grid infrastructure software configuration  & Database Creation";tput sgr0
     echo -e "\n\n"
     exit 1;;
  *) echo -e " \e[1;91m $opt is an invaild option. Please select option between 1-4 only ";tput sgr0
     echo -e "\n\n"
     echo -e " \033[0;90m \033[1;94m Press [enter] key to continue. . .";tput sgr0
     read enterKey
     ;;
esac
done
###################################################################################################################################################################

#!THIS BLOCK WILL PROMPT TO ENTER INPUT FOR GLOBAL DB NAME,CDB INSTANCE NAME AND PDB NAME 

while :
do
echo -e " \033[0;100m \033[1;97m 12c(12.1.0)Grid infrastructure software and ASM configuration started !!!!!!!!!!!";tput sgr0
echo -e "\n\n\n\n"

echo -e "\033[0;100m \033[1;97m";read -p "Enter Global CDB name (Example: <<CDB_NAME>CDB.GLOBAL.TESCO.ORG>) : " GLOBAL_CDB_NAME;tput sgr0
while [[ $GLOBAL_CDB_NAME == '' ]]
do
    echo -e "  \e[1;91m Enter a valid GLOBAL CDB NAME :";tput sgr0
    echo -e "\033[0;100m \033[1;97m";read -p "Enter Global CDB name (Example: <<CDB_NAME>CDB.GLOBAL.TESCO.ORG>) : " GLOBAL_CDB_NAME;tput sgr0
done

echo -e "\033[0;100m \033[1;97m";read -p "Enter CDB SID (Example : <CDB_SID>CDB) : " CDB_SID;tput sgr0

while [[ $CDB_SID == '' ]]
do
    echo -e "  \e[1;91m Enter a valid CDB SID ";tput sgr0
    echo -e "\033[0;100m \033[1;97m";read -p "Enter CDB SID (Example : <CDB_SID>CDB) : " CDB_SID;tput sgr0

done

echo -e "\033[0;100m \033[1;97m";read -p "Enter PDB name : " PDBNAME;tput sgr0

while [[ $PDBNAME == '' ]]
do
    echo -e "  \e[1;91m Enter a valid PDB NAME ";tput sgr0
    echo -e "\033[0;100m \033[1;97m";read -p "Enter PDB name : " PDBNAME;tput sgr0

done

echo -e "\033[0;100m \033[1;97m";read -p "Enter Grid Software Directory Path : " GRID_SOFTWARE_DIRECTORY_PATH;tput sgr0

while : ; do
if [[ $GRID_SOFTWARE_DIRECTORY_PATH != '' ]]; then

 if [[ -d "$GRID_SOFTWARE_DIRECTORY_PATH" ]]; then

   if [[ -f "$GRID_SOFTWARE_DIRECTORY_PATH/grid_x.tgz" ]]; then
   break
else
    echo -e "  \e[1;91m Grid Software File(grid_x.tgz) doesn't exists in the directory $GRID_SOFTWARE_DIRECTORY_PATH ";tput sgr0
    echo -e "\n\n"
    echo -e "\033[0;100m \033[1;97m";read -p "Enter Grid Software Directory Path : " GRID_SOFTWARE_DIRECTORY_PATH;tput sgr0
    echo -e "\n\n"
fi
else
echo -e "  \e[1;91m Directory path $GRID_SOFTWARE_DIRECTORY_PATH doesn't exists ";tput sgr0
    echo -e "\n\n"
    echo -e "\033[0;100m \033[1;97m";read -p "Enter Grid Software Directory Path : " GRID_SOFTWARE_DIRECTORY_PATH;tput sgr0
    echo -e "\n\n"
fi
else
echo -e "  \e[1;91m Please enter a valid Grid Directory Path ";tput sgr0
    echo -e "\n\n"
    echo -e "\033[0;100m \033[1;97m";read -p "Enter Grid Software Directory Path : " GRID_SOFTWARE_DIRECTORY_PATH;tput sgr0
    echo -e "\n\n"
fi
done

echo -e "\033[0;100m \033[1;97m";read -p "Enter Database Software Directory Path : " DB_SOFTWARE_DIRECTORY_PATH;tput sgr0


while : ; do
if [[ $DB_SOFTWARE_DIRECTORY_PATH != '' ]]; then

 if [[ -d "$DB_SOFTWARE_DIRECTORY_PATH" ]]; then

   if [[ -f "$DB_SOFTWARE_DIRECTORY_PATH/db_x.tgz" ]]; then
 break
else
    echo -e "  \e[1;91m Database Software File(db_x.tgz) doesn't exists in the directory $DB_SOFTWARE_DIRECTORY_PATH ";tput sgr0
    echo -e "\n\n"
    echo -e "\033[0;100m \033[1;97m";read -p "Enter Database Software Directory Path : " DB_SOFTWARE_DIRECTORY_PATH;tput sgr0
    echo -e "\n\n"
fi
else
echo -e "  \e[1;91m Directory path $DB_SOFTWARE_DIRECTORY_PATH doesn't exists";tput sgr0
    echo -e "\n\n"
    echo -e "\033[0;100m \033[1;97m";read -p "Enter Database Software Directory Path : " DB_SOFTWARE_DIRECTORY_PATH;tput sgr0
    echo -e "\n\n"
fi
else
echo -e "  \e[1;91m Please enter a valid Database Software Directory Path ";tput sgr0
    echo -e "\n\n"
    echo -e "\033[0;100m \033[1;97m";read -p "Enter Database Software Directory Path : " DB_SOFTWARE_DIRECTORY_PATH;tput sgr0
    echo -e "\n\n"
fi
done

echo -e " \033[0;100m \033[1;97m You have entered below values for GLOBAL CDB NAME, CDB NAME,PDB NAME, GRID SOFTWARE DIRECTORY PATH & DB SOFTWARE DIRECTORY PATH. IF ALL BELOW INFORMATION ARE CORRECT YOU CAN CONTINUE. ELSE RE_ENTER THE INPUT VALUES ";tput sgr0
echo -e "\n\n"

echo -e " \033[0;100m \033[1;97m GLOBAL CDB NAME : $GLOBAL_CDB_NAME";echo " CDB SID : $CDB_SID";echo " PDB NAME : $PDBNAME";echo " GRID SOFTWARE DIRECTORY PATH : $GRID_SOFTWARE_DIRECTORY_PATH";echo " DB SOFTWARE DIRECTORY PATH : $DB_SOFTWARE_DIRECTORY_PATH";tput sgr0

while true
do
    echo -e "\033[0;100m \033[1;97m";read -p "Do you want to proceed (y/n) : " PROCEED;tput sgr0
    case $PROCEED in
      n|N) echo -e " \e[1;91m 12c(12.1.0.5) grid infrastructure installation and ASM configuration Wizard restated. Please re-enter the input values for GLOBAL DB NAME, DB SID, GRID SOFTWARE DIRECTORY PATH & DB SOFTWARE DIRECTORY PATH ";tput sgr0
           echo -e "\n\n"
           break;;
      y|Y) echo -e "\033[0;100m \033[1;97m Proceeding with 12c(12.1.0.5) grid infrastructure installation and ASM configuration ";tput sgr0
           echo -e "\n\n"
           break 2;;
      *) echo -e " \e[1;91m Response not valid ";tput sgr0
         echo -e "\n\n";;
    esac
done
done


####################################################################################################################################################################

#!THIS BLOCK WILL CERATE GRID & ORAINVENTORY DIRECTORIES FOR GRID INFRASTRUSTURE INSTALLSTION

echo -e " \033[0;100m \033[1;97m ####### Creating grid directory under /u00/app: `date`............";tput sgr0
echo -e "\n\n\n\n"
mkdir -p /u00/app
chmod 775 /u00/app 
mkdir -p /u00/app/grid
chmod 755 /u00/app/grid
mkdir -p /u00/app/grid/product/12.1.0
chmod 755 /u00/app/grid/product/12.1.0


echo -e " \033[0;100m \033[1;97m  ####### Grid directory  is created under /u00/app: `date`......... ";tput sgr0
echo -e "\n\n\n\n"

echo -e " \033[0;100m \033[1;97m ####### Creating OraInventory directory under /u00/app: `date`............. ";tput sgr0
echo -e "\n\n\n\n"

#chmod 775 /u00/app
mkdir -p /u00/app/oraInventory
chmod 775 /u00/app/oraInventory


echo -e " \033[0;100m \033[1;97m  ####### OraInventory directory  is created under /u00/app: `date`...... ";tput sgr0
echo -e "\n\n\n\n"
echo -e "################################################################# "
echo -e "\n\n\n\n"

#################################################################################################################################################################

#!THIS BLOCK WILL EXTRACT THE GRID INFRASTRUCTURE CLONE SOFTWARE AND MOVE THE EXTRACTED DIRECTORY

echo -e " \033[0;100m \033[1;97m ####### Now Extracting Grid software: `date`.............";tput sgr0
echo -e "\n\n\n\n"
tar xvfpz $GRID_SOFTWARE_DIRECTORY_PATH/grid_x.tgz -C /u00/app/grid/product/12.1.0 > /u00/app/grid/grid_software_extract.log 2>&1
retcode1=${?}
if [[ ${retcode1} -eq 0 ]]; then

while true
do
while (/bin/egrep -i -A 5 'warning:|error:|command not found|No such file or directory' /u00/app/grid/grid_software_extract.log);
do
   read -p " ERROR Found in output logfile !! Please verify the /u00/app/grid/grid_software_extract.log before proceed . Do you want to proceed (y/n) :" PROCEED
    case $PROCEED in
      n|N) echo -e " \e[1;91m ERROR Found in output logfile !! Grid Software Extract Failed !! Database(CDB with PDB) Creation Cancelled !!!!";tput sgr0
           echo -e "\n\n"
           exit -1;;
      y|Y) echo -e " \033[0;100m \033[1;97m Proceeding with GRID Software directory movement .... ";tput sgr0
           echo -e "\n\n"
           break 3;;
      *) echo -e " \e[1;91m Response not valid !!!! ";tput sgr0
         echo -e "\n\n";;
    esac
done   
echo -e " \033[0;100m \033[1;97m Please verify the /u00/app/grid/grid_software_extract.log before proceed . .... ";tput sgr0
echo -e "\n\n"
echo -e "\033[0;100m \033[1;97m";read -p "Do you want to proceed (y/n) : " PROCEED;tput sgr0
case $PROCEED in
      n|N) echo -e " \e[1;91m Grid Software installation & Database(CDB with PDB) Creation Cancelled !!!!";tput sgr0
           echo -e "\n\n"
           exit -1;;
      y|Y) echo -e " \033[0;100m \033[1;97m Proceeding with GRID Software directory movement .... ";tput sgr0
           echo -e "\n\n"
           break;;
      *) echo -e " \e[1;91m Response not valid !!!!";tput sgr0
         echo -e "\n\n";;
    esac
done

mv /u00/app/grid/product/12.1.0/grid_x /u00/app/grid/product/12.1.0/grid_1 > /u00/app/grid/grid_software_movement.log 2>&1
retcode2=${?}
if [[ ${retcode2} -eq 0 ]]; then

while true
do
while (/bin/egrep -i -A 5 'warning:|error:|command not found|No such file or directory' /u00/app/grid/grid_software_movement.log);
do
   read -p " ERROR Found in output logfile !! Please verify the /u00/app/grid/grid_software_movement.log before proceed . Do you want to proceed (y/n) :" PROCEED
    case $PROCEED in
      n|N) echo -e " \e[1;91m ERROR Found in output logfile !! Grid Software Movement Failed !! Database(CDB with PDB) Creation Cancelled !!!!";tput sgr0
           echo -e "\n\n"
           exit -1;;
      y|Y) echo -e " \033[0;100m \033[1;97m Proceeding with GRID Software installation in Progress : Now granting Permission to Grid Binary & Library files....";tput sgr0
           echo -e "\n\n"
           break 3;;
      *) echo -e " \e[1;91m Response not valid !!!!";tput sgr0
         echo -e "\n\n";;
    esac
done

echo -e " \033[0;100m \033[1;97m Please verify the /u00/app/grid/grid_software_movement.log before proceed . ....";tput sgr0
echo -n "\n\n"

echo -e "\033[0;100m \033[1;97m";read -p "Do you want to proceed (y/n) : " PROCEED;tput sgr0

case $PROCEED in
      n|N) echo -e " \e[1;91m Grid Software installation & Database(CDB with PDB) Creation Cancelled !!!! ";tput sgr0
           echo -e "\n\n"
           exit -1;;
      y|Y) echo -e " \033[0;100m \033[1;97m Proceeding with granting Permission to Grid Binary & Library files .... ";tput sgr0
           echo -e "\n\n"
           break;;
      *) echo -e " \e[1;91m Response not valid !!!! ";tput sgr0
         echo -e "\n\n";;
    esac
done

echo -e "\e[1;92m ####### Grid Software has been extracted: `date`.................. ";tput sgr0
echo -e "\n\n"
else
echo -e "\e[1;91m ####### Grid folder movement failed: `date`....................... ";tput sgr0
echo -e "\n\n"
exit -1
fi
else
echo -e "\e[1;91m ####### Grid extraction failed: `date`...... ";tput sgr0
echo -e "\n\n"
exit -1
fi

echo -e " ########################################################################################################### \n\n"

##################################################################################################################################################################

#!THIS BLOCK WILL GRANT PERMISSION TO GRID BINARY AND LIBRARY FILES

echo -e " \033[0;100m \033[1;97m ####### Now GRANTING PERMISSION TO GRID BINARY & LIBRARY FILES: `date`...... ";tput sgr0
echo -e "\n\n\n\n"
chmod -R 755 /u00/app/grid/product/12.1.0/grid_1
chmod 644 /u00/app/grid/product/12.1.0/grid_1/jdk/jre/javaws/javaws /u00/app/grid/product/12.1.0/grid_1/jdk/jre/lib/amd64/server/libjsig.so
echo -e "\e[1;92m ####### PERMISSION GRANTED FOR GRID BINARY & LIBRARY FILES: `date`...... \n\n\n\n";tput sgr0
echo -e " ######################################################################################################################  \n\n "

#####################################################################################################################################################################

#!THIS WILL BLOCK WILL ATTACH THE GRID BINARIES AND RUN THE ROOT.SH & ROOHAS.PL SCRIPT TO START THE AVAILABLIITY SERVICE 


echo -e " \033[0;100m \033[1;97m ###### Grid software installation started: `date`...... ";tput sgr0
echo -e "\n\n"
/u00/app/grid/product/12.1.0/grid_1/oui/bin/runInstaller -clone -silent INVENTORY_LOCATION="/u00/app/oraInventory" -waitForCompletion -ignorePreReq ORACLE_HOME="/u00/app/grid/product/12.1.0/grid_1" ORACLE_HOME_NAME="GRID_12c_HOME1" ORACLE_BASE="/u00/app/grid" oracle_install_OSDBA=oinstall oracle_install_OSOPER=oper > /u00/app/grid/grid_software_installation.log 2>&1
retcode3=${?}

if [[ ${retcode3} -eq 0 ]]; then
while true
do
while (/bin/egrep -i -A 5 'err:|ora-|warning:|error:|command not found|No such file or directory' /u00/app/grid/grid_software_installation.log);
do
   read -p " ERROR Found in output logfile !! Please verify the /u00/app/grid/grid_software_installation.log before proceed . Do you want to proceed (y/n) :" PROCEED
    case $PROCEED in
      n|N) echo -e " \e[1;91m ERROR Found in output logfile !! Grid Software installation failed !!! Database(CDB with PDB) Creation Cancelled !!!! ";tput sgr0
           echo -e "\n\n"
           exit -1;;
      y|Y) echo -e " \033[0;100m \033[1;97m Now Proceeding with orainstRoot.sh script execution of GRID Software installation ..... ";tput sgr0
           echo -e "\n\n"
           break 3;;
      *) echo -e " \e[1;91m Response not valid !!!! ";tput sgr0
         echo -e "\n\n";;
    esac
done
echo -e " \033[0;100m \033[1;97m Please verify the /u00/app/grid/grid_software_installation.log before proceed . .... ";tput sgr0
echo -e "\n\n"
echo -e "\033[0;100m \033[1;97m";read -p "Do you want to proceed (y/n) : " PROCEED;tput sgr0
case $PROCEED in
      n|N) echo -e " \e[1;91m Grid Software installation & Database(CDB with PDB) Creation Cancelled !!!! ";tput sgr0
           echo -e "\n\n"
           exit -1;;
      y|Y) echo -e " \033[0;100m \033[1;97m Now Proceeding with orainstRoot.sh script execution of GRID Software installation ..... ";tput sgr0
           echo -e "\n\n"
           break;;
      *) echo -e " \e[1;91m Response not valid !!!! ";tput sgr0
         echo -e "\n\n";;
    esac
done

######################################################################################################################################################################

#!THIS BLOCK WILL EXECUTE THE OrainstRoot.SH SCRIPT FOR GRID INSTALLATION

echo -e " \033[0;100m \033[1;97m ######## Now Executing orainstRoot.sh script for Grid installation started at: `date`...... ";tput sgr0
echo -e "\n\n"
sudo /u00/app/oraInventory/orainstRoot.sh > /u00/app/grid/grid_installation_orainstRoot_sh.log 2>&1
retcode55=${?}
if [[ ${retcode55} -eq 0 ]]; then

while true
do
while (/bin/egrep -i -A 5 'err:|ora-|warning:|error:|command not found|No such file or directory' /u00/app/grid/grid_installation_orainstRoot_sh.log);
do
   read -p "ERROR Found in output logfile !!Please verify the /u00/app/grid/grid_installation_orainstRoot_sh.log before proceed .Do you want to proceed (y/n) :" PROCEED
    case $PROCEED in
      n|N) echo -e " \e[1;91m ERROR Found in output logfile !! orainstRoot.sh for Grid Software installation Failed !!! Grid Software installation & Database(CDB with PDB) Creation Cancelled !!!!";tput sgr0
           echo -e "\n\n"
           exit -1;;
      y|Y) echo -e " \033[0;100m \033[1;97m Now Proceeding with root.sh script execution of Grid Software installation  .... ";tput sgr0
           echo -e "\n\n"
           break 3;;
      *) echo -e " \e[1;91m Response not valid !!!!";tput sgr0
         echo -e "\n\n";;
    esac
done

echo -e " \033[0;100m \033[1;97m Please verify the /u00/app/grid/grid_installation_orainstRoot_sh.log before proceed . .... ";tput sgr0
echo -e "\033[0;100m \033[1;97m";read -p "Do you want to proceed (y/n) : " PROCEED;tput sgr0
case $PROCEED in
      n|N) echo -e " \e[1;91m Grid Software installation & Database(CDB with PDB) Creation Cancelled !!!!";tput sgr0
           echo -e "\n\n"
           exit -1;;
      y|Y) echo -e " \033[0;100m \033[1;97m Now Proceeding with root.sh script execution of Grid Software installation  ....";tput sgr0
           echo -e "\n\n"
           break;;
      *) echo -e " \e[1;91m Response not valid !!!!";tput sgr0
         echo -e "\n\n";;
    esac
done

echo -e "\e[1;92m ####### GRID Software installation in Progress : orainstRoot.sh script executed succesfully at: `date`.............";tput sgr0
echo -e "\n\n"

######################################################################################################################################################################
#!THIS BLOCK WILL EXECUTE THE ROOT.SH SCRIPT FOR GRID INSTALLATION

echo -e " \033[0;100m \033[1;97m ######## Now Executing root.sh script for Grid installation started at: `date`...... ";tput sgr0
echo -e "\n\n"
sudo /u00/app/grid/product/12.1.0/grid_1/root.sh > /u00/app/grid/grid_installation_root_sh.log 2>&1
retcode4=${?}
if [[ ${retcode4} -eq 0 ]]; then
while true
do
while (/bin/egrep -i -A 5 'err:|ora-|warning:|error:|command not found|No such file or directory' /u00/app/grid/grid_installation_root_sh.log);
do
   read -p " ERROR Found in output logfile !! Please verify the /u00/app/grid/grid_installation_root_sh.log before proceed . Do you want to proceed (y/n) :" PROCEED
    case $PROCEED in
      n|N) echo -e " \e[1;91m ERROR Found in output logfile !! root.sh for Grid Software installation Failed !!! Database(CDB with PDB) Creation Cancelled !!!!";tput sgr0
           echo -e "\n\n"
           exit -1;;
      y|Y) echo -e " \033[0;100m \033[1;97m Now Proceeding with roothas.pl script execution of Grid Software installation  .... ";tput sgr0
           echo -e "\n\n"
           break 3;;
      *) echo -e " \e[1;91m Response not valid !!!!";tput sgr0
         echo -e "\n\n";;
    esac
done

echo -e " \033[0;100m \033[1;97m Please verify the /u00/app/grid/grid_installation_root_sh.log before proceed . .... ";tput sgr0

echo -e "\033[0;100m \033[1;97m";read -p "Do you want to proceed (y/n) : " PROCEED;tput sgr0

case $PROCEED in
      n|N) echo -e " \e[1;91m Grid Software installation & Database(CDB with PDB) Creation Cancelled !!!!";tput sgr0
           echo -e "\n\n"
           exit -1;;
      y|Y) echo -e " \033[0;100m \033[1;97m Now Proceeding with roothas.pl script execution of Grid Software installation  ....";tput sgr0
           echo -e "\n\n"
           break;;
      *) echo -e " \e[1;91m Response not valid !!!!";tput sgr0
         echo -e "\n\n";;
    esac
done

echo -e "\e[1;92m ####### GRID Software installation in Progress : root.sh  script executed succesfully at: `date`.............";tput sgr0
echo -e "\n\n"

######################################################################################################################################################################

#!THIS BLOCK WILL PERFORM THE ROOTHAS.PL SCRIPT EXECUTION FOR GRID INFRASTRUCTURE INSTALLATION

echo -e " \033[0;100m \033[1;97m ##### GRID Software installation in Progress : Now Executing roothas.pl script: `date`..................... \n\n\n\n";tput sgr0
sudo /u00/app/grid/product/12.1.0/grid_1/perl/bin/perl -I/u00/app/grid/product/12.1.0/grid_1/perl/lib -I/u00/app/grid/product/12.1.0/grid_1/crs/install /u00/app/grid/product/12.1.0/grid_1/crs/install/roothas.pl > /u00/app/grid/grid_installation_roothas_pl.log 2>&1
retcode5=${?}
if [[ ${retcode5} -eq 0 ]]; then
while true
do
while (/bin/egrep -i -A 5 'err:|ora-|warning:|error:|command not found|No such file or directory' /u00/app/grid/grid_installation_roothas_pl.log);
do
   read -p " ERROR Found in output logfile !! Please verify the /u00/app/grid/grid_installation_roothas_pl.log before proceed . Do you want to proceed (y/n) :" PROCEED
    case $PROCEED in
      n|N) echo -e " \e[1;91m ERROR Found in output logfile !! roothas.pl script for Grid Software installation failed !!! Database(CDB with PDB) Creation Cancelled !!!!";tput sgr0
           echo -e "\n\n"
           exit -1;;
      y|Y) echo -e " \033[0;100m \033[1;97m Now Proceeding with GRID LISTENER Creation ....";tput sgr0
           echo -e "\n\n"
           break 3;;
      *) echo -e " \e[1;91m Response not valid !!!!";tput sgr0
         echo -e "\n\n";;
    esac
done

echo -e " \033[0;100m \033[1;97m Please verify the /u00/app/grid/grid_installation_roothas_pl.log before proceed . ....";tput sgr0
echo -e "\n\n"
echo -e "\033[0;100m \033[1;97m";read -p "Do you want to proceed (y/n) : " PROCEED;tput sgr0

case $PROCEED in
      n|N) echo -e " \e[1;91m Grid Software installation & Database(CDB with PDB) Creation Cancelled !!!!";tput sgr0
           echo -e "\n\n"
           exit -1;;
      y|Y) echo -e " \033[0;100m \033[1;97m Now Proceeding with GRID LISTENER Creation .... ";tput sgr0
           echo -e "\n\n"
           break;;
      *) echo -e " \e[1;91m Response not valid !!!! ";tput sgr0
         echo -e "\n\n";;
    esac
done


echo -e "\e[1;92m ####### GRID Software Installation in progress : roothas.pl executed succesfully at: `date`.................. ";tput sgr0
echo -e "\n\n"
echo -e "\e[1;92m ####### Grid software installation completed succesfully: `date`... ";tput sgr0
echo -e "\n\n"
else
echo -e "\e[1;91m ##### Grid installation failed: `date` ############################ ";tput sgr0
echo -e "\n\n"
exit -1
fi
else
echo -e "\e[1;91m ##### OrainstRoot.sh is failed: `date` ###################################  ";tput sgr0
echo -e "\n\n"
exit -1
fi
else
echo -e "\e[1;91m ##### root.sh is failed: `date` ###################################  ";tput sgr0
echo -e "\n\n"
exit -1
fi
else
echo -e "\e[1;91m ##### Grid clone Script is failed: `date` ################################ ";tput sgr0
echo -e "\n\n"
exit -1
fi
echo -e " ############################################################################################################################# "

###################################################################################################################################################################

#!THIS BLOCK WILL CREATE AND START THE GRID LISTENER SERVICE 

echo -e "\n\n"
echo -e " \033[0;100m \033[1;97m ###### NOW STARTING GRID LISTENER CREATION : `date`...... ";tput sgr0
echo -e "\n\n\n\n"
/u00/app/grid/product/12.1.0/grid_1/bin/netca /silent /responseFile /u00/app/grid/product/12.1.0/grid_1/assistants/netca/netca.rsp > /u00/app/grid/grid_listener_creation.log 2>&1
retcode6=${?}
if [[ ${retcode6} -eq 0 ]]; then
while true
do
while (/bin/egrep -i -A 5 'err:|ora-|warning:|error:|command not found|No such file or directory' /u00/app/grid/grid_listener_creation.log);
do
   read -p " ERROR Found in output logfile !! Please verify the /u00/app/grid/grid_listener_creation.log before proceed . Do you want to proceed (y/n) :" PROCEED
    case $PROCEED in
      n|N) echo -e " \e[1;91m ERROR Found in output logfile !! Grid Listener Creation failed !!! Database(CDB with PDB) Creation Cancelled !!!! ";tput sgr0
           echo -e "\n\n"
           exit -1;;
      y|Y) echo -e " \033[0;100m \033[1;97m Now Proceeding with GRID ASM instance & DIskgroup Creation ....... ";tput sgr0
           echo -e "\n\n"
           break 3;;
      *) echo -e " \e[1;91m Response not valid !!!! ";tput sgr0
         echo -e "\n\n";;
    esac
done

echo -e " \033[0;100m \033[1;97m Please verify the /u00/app/grid/grid_listener_creation.log before proceed . ....... ";tput sgr0
echo -e "\n\n"
echo -e "\033[0;100m \033[1;97m";read -p "Do you want to proceed (y/n) : " PROCEED;tput sgr0

case $PROCEED in
      n|N) echo -e " \e[1;91m Grid Software installation & Database(CDB with PDB) Creation Cancelled !!!! ";tput sgr0
           echo -e "\n\n"
           exit -1;;
      y|Y) echo -e " \033[0;100m \033[1;97m Now Proceeding with GRID ASM instance & DIskgroup Creation ...... ";tput sgr0
           echo -e "\n\n"
           break;;
      *) echo -e " \e[1;91m Response not valid !!!! ";tput sgr0
         echo -e "\n\n";;
    esac
done

echo -e "\e[1;92m ####### GRID LISTENER CREATED SUCCESSFULLY at: `date`.........................";tput sgr0
echo -e "\n\n"
else
echo -e "\e[1;91m ######## Grid Listener Creation failed: `date` ################################ ";tput sgr0
echo -e "\n\n"
exit -1
fi
echo -e " ############################################################################################################################################  "
echo -e "\n\n\n\n"

####################################################################################################################################################################

#!THIS BLOCK WILL CREATE THE ASM INSTANCE AND +ORADATA DISKGROUP AS A PART OF GRID INFRASTRUCTURE CONFIGURATION

echo -e " \033[0;100m \033[1;97m #####  Now creating ASM INSTANCE & ORADATA DISKGROUP : `date`........................";tput sgr0
echo -e "\n\n\n\n"
/u00/app/grid/product/12.1.0/grid_1/bin/asmca -silent -configureASM -sysAsmPassword ta5uSEswacheSW  -asmsnmpPassword  ta5uSEswacheSW -diskString "/dev/oracleasm/disks/*" -diskGroupName ORADATA -disk /dev/oracleasm/disks/ORCLDISKORADATA01 -redundancy EXTERNAL -compatible.asm 12.1 -compatible.rdbms 11.2 -compatible.advm 12.1 > /u00/app/grid/ASM_instance_ORADATA_DISKGROUP_creation.log 2>&1
retcode7=${?}
if [[ ${retcode7} -eq 0 ]]; then

while true
do
while (/bin/egrep -i -A 5 'err:|ora-|warning:|error:|command not found|No such file or directory' /u00/app/grid/ASM_instance_ORADATA_DISKGROUP_creation.log);
do
   read -p " ERROR Found in output logfile !! Please verify the /u00/app/grid/ASM_instance_ORADATA_DISKGROUP_creation.log before proceed . Do you want to proceed (y/n) :" PROCEED
    case $PROCEED in
      n|N) echo -e " \e[1;91m ERROR Found in output logfile !! GRID ASM instance & ORADATA Diskgroup creation failed !!! Database(CDB with PDB) Creation Cancelled !!!!";tput sgr0
           echo -e "\n\n"
           exit -1;;
      y|Y) echo -e " \033[0;100m \033[1;97m Now Proceeding with +ORARECO Diskgroup Creation ........ ";tput sgr0
           echo -e "\n\n"
           break 3;;
      *) echo -e " \e[1;91m Response not valid !!!!!!!! ";tput sgr0
         echo -e "\n\n";;
    esac
done

echo -e " \033[0;100m \033[1;97m Please verify the /u00/app/grid/ASM_instance_ORADATA_DISKGROUP_creation.log before proceed . ......... ";tput sgr0
echo -e "\n\n"
echo -e "\033[0;100m \033[1;97m";read -p "Do you want to proceed (y/n) : " PROCEED;tput sgr0

case $PROCEED in
      n|N) echo -e " \e[1;91m Grid Software installation & Database(CDB with PDB) Creation Cancelled !!!!";tput sgr0
           echo -e "\n\n"
           exit -1;;
      y|Y) echo -e " \033[0;100m \033[1;97m Now Proceeding with GRID ASM +ORARECO Diskgroup Creation .... ";tput sgr0
           echo -e "\n\n"
           break;;
      *) echo -e " \e[1;91m Response not valid !!!! ";tput sgr0
         echo -e "\n\n";;
    esac
done

echo -e "\e[1;92m #######  ASM instance & ORADATA DISKGROUP Created Successfully at: `date`.. ";tput sgr0

###################################################################################################################################################################

#!THIS BLOCK WILL CREATE ASM +ORARECO DISKGROUP AS A PART OF GRID INFRASTRUCTURE CONFIGURATION

echo -e " \033[0;100m \033[1;97m ##### Now creating ORARECO diskgroup: `date` .... \n\n\n\n";tput sgr0
/u00/app/grid/product/12.1.0/grid_1/bin/asmca -silent -createDiskGroup -diskGroupName ORARECO -disk /dev/oracleasm/disks/ORCLDISKORARECO01 -redundancy EXTERNAL -compatible.asm 12.1 -compatible.rdbms 11.2 -compatible.advm 12.1 > /u00/app/grid/ASM_ORARECO_DISKGROUP_creation.log 2>&1
retcode8=${?}
if [[ ${retcode8} -eq 0 ]]; then

while true
do
while (/bin/egrep -i -A 5 'err:|ora-|warning:|error:|command not found|No such file or directory' /u00/app/grid/ASM_ORARECO_DISKGROUP_creation.log);
do
   read -p " ERROR Found in output logfile !! Please verify the /u00/app/grid/ASM_ORARECO_DISKGROUP_creation.log before proceed . Do you want to proceed (y/n) :" PROCEED
    case $PROCEED in
      n|N) echo -e " \e[1;91m ERROR Found in output logfile !! GRID ASM +ORARECO Diskgroup creation failed !!! Grid ASM instance Configuration & Database(CDB with PDB) Creation Cancelled !!!! ";tput sgr0
           echo -e "\n\n"
           exit -1;;
      y|Y) echo -e " \033[0;100m \033[1;97m Now Proceeding with PERMISSION modification for Oracle file ON GRID HOME ........ ";tput sgr0
           echo -e "\n\n"
           break 3;;
      *) echo -e " \e[1;91m Response not valid !!!!!!! ";tput sgr0
         echo -e "\n\n";;
    esac
done

echo -e " \033[0;100m \033[1;97m Please verify the /u00/app/grid/ASM_ORARECO_DISKGROUP_creation.log before proceed . .............. ";tput sgr0
echo -e "\n\n"

echo -e "\033[0;100m \033[1;97m";read -p "Do you want to proceed (y/n) : " PROCEED;tput sgr0

case $PROCEED in
      n|N) echo -e " \e[1;91m Grid ASM instance Configuration & Database(CDB with PDB) Creation Cancelled !!!!!! ";tput sgr0
           echo -e "\n\n"
           exit -1;;
      y|Y) echo -e " \033[0;100m \033[1;97m Now Proceeding with PERMISSION modification for Oracle file ON GRID HOME ....... ";tput sgr0
           echo -e "\n\n"
           break;;
      *) echo -e " \e[1;91m Response not valid !!!! ";tput sgr0
         echo -e "\n\n";;
    esac
done



echo -e "\e[1;92m ####### +ORARECO Diskgroup Creation completed succesfully at: `date`............. ";tput sgr0
echo -e "\n\n\n\n"
echo -e "\e[1;92m #######  ASM INSTANCE & DISKGROUP CREATION SUCCESSFULLY COMPLTED: `date`.........";tput sgr0
echo -e "\n\n\n\n"
else
echo -e "\e[1;91m ##### +ORARECO Diskgroup Creation failed at: `date`.......................... ";tput sgr0
echo -e "\n\n\n\n"
exit -1
fi
else
echo -e "\e[1;91m #####  ASM INSTANCE & DISKGROUP CREATION FAILED: `date`..................... ";tput sgr0
echo -e "\n\n\n\n"
exit -1
fi
echo -e " ############################################################################################################################################### "
echo -e "\n\n\n\n"

#################################################################################################################################################################

#!THIS BLOCK WILL CHANGE THE PERMISSION OF oracle file ON GRID HOME

echo -e " \033[0;100m \033[1;97m ##### Change the PERMISSION for Oracle file ON GRID HOME: `date`.............. ";tput sgr0
echo -e "\n\n\n\n"
chmod 6751 /u00/app/grid/product/12.1.0/grid_1/bin/oracle
retcode9=${?}
if [[ ${retcode9} -eq 0 ]]; then
echo -e "\e[1;92m ####### PERMISSION for Oracle file ON GRID HOME HAS SUCCESSFULLY CHANGED : `date`......... ";tput sgr0
echo -e "\n\n\n\n"
else
echo -e "\e[1;91m PERMISSION modification for Oracle file ON GRID HOME HAS FAILED: `date`.................... ";tput sgr0
echo -e "\n\n\n\n"
exit -1
fi

##################################################################################################################################################################

#!THIS BLOCK WILL SSH TO ORACLE USER AND CREATE DIRECTORIES FOR ORACLE DATABASE SOFTWARE INSTALLATION

echo -e "  \033[0;100m \033[1;97m ####### Now login to ORACLE user and create the directories for oracle database software installation: `date` ......... ";tput sgr0
echo -e "\n\n\n\n"
export HOST=`hostname`

ssh -t oracle@$HOST  'export GLOBAL_CDB_NAME='"'$GLOBAL_CDB_NAME'"';export CDB_SID='"'$CDB_SID'"';export PDBNAME='"'$PDBNAME'"';export TEMPLATE='"'$TEMPLATE'"';export DB_SOFTWARE_DIRECTORY_PATH='"'$DB_SOFTWARE_DIRECTORY_PATH'"';/u00/app/grid/12c_oracle_script.sh'

