#######################################################################################################################################################################
#!THIS BLOCK WILL CALL SCRIPT 12c_grid_script.sh AND OUTPUT LOG WILL BE GENERATED IN /u00/app/grid/12c_grid_oracle_installation.log FILE

bash /u00/app/grid/12c_grid_script.sh 2>&1 | tee /u00/app/grid/12c_grid_oracle_installation.log

