#################################################################################################################################################################

#!THIS BLOCK WILL CREATE DIRECTORIES FOR ORACLE DATABASE SOFTWARE INSTALLATION

mkdir -p /u00/app/oracle
mkdir -p /u00/app/oracle/product/12.1.0
chmod -R 755 /u00/app/oracle/product/12.1.0

echo -e "\e[1;92m ####### Oracle directory creation completed succesfully : `date` ................... ";tput sgr0
echo -e "\n\n\n\n"

##################################################################################################################################################################

#! THIS BLOCK WILL EXTRACT ORACLE DATABSE SOFTWARE FOR DATABASE SOFTWARE INSTALLATION

echo -e " \033[0;100m \033[1;97m ####### Now Extracting Oracle database software: `date`........... ....";tput sgr0
tar xvfpz $DB_SOFTWARE_DIRECTORY_PATH/db_x.tgz -C /u00/app/oracle/product/12.1.0 > /u00/app/oracle/oracle_software_extraction.log 2>&1
retcode10=${?}
if [[ ${retcode10} -eq 0 ]]; then
while true
do
while (/bin/egrep -i -A 5 'warning:|error:|command not found|No such file or directory' /u00/app/oracle/oracle_software_extraction.log);
do
   read -p " ERROR Found in output logfile !! Please verify the /u00/app/oracle/oracle_software_extraction.log before proceed . Do you want to proceed (y/n) :" PROCEED
    case $PROCEED in
      n|N) echo -e " \e[1;91m ERROR Found in output logfile !! Oracle Database Software Extract Failed !! Database(CDB with PDB) Creation Cancelled !!!!";tput sgr0
           echo -e "\n\n"
           exit -1;;
      y|Y) echo -e " \033[0;100m \033[1;97m Now Proceeding with Oracle Database Software Movement & Software installation .... ";tput sgr0
           echo -e "\n\n"
           break 3;;
      *) echo -e " \e[1;91m Response not valid !!!!";tput sgr0
          echo -e "\n\n";;
    esac
done
echo -e " \033[0;100m \033[1;97m Please verify the /u00/app/oracle/oracle_software_extraction.log before proceed . ....... ";tput sgr0
echo -e "\n\n"
echo -e "\033[0;100m \033[1;97m";read -p "Do you want to proceed (y/n) : " PROCEED;tput sgr0
case $PROCEED in
      n|N) echo -e " \e[1;91m Oracle Database Software Extract Failed !! Database(CDB with PDB) Creation Cancelled !!!!";tput sgr0
           echo -e "\n\n"
           exit -1;;
      y|Y) echo -e " \033[0;100m \033[1;97m Now Proceeding with Oracle Database Software Movement & Software installation ....... ";tput sgr0
           echo -e "\n\n"
           break;;
      *) echo -e " \e[1;91m Response not valid !!!! ";tput sgr0
         echo -e "\n\n";;
    esac
done

#####################################################################################################################################################################

#!THIS BLOCK WILL MOVE THE ORACLE DATABASE SOFTWARE MOVEMNT FOE DATABASE SOFTWARE INSTALLATION

mv /u00/app/oracle/product/12.1.0/db_x /u00/app/oracle/product/12.1.0/db_1 > /u00/app/oracle/oracle_software_movement.log 2>&1
retcode11=${?}
if [[ ${retcode11} -eq 0 ]]; then

while true
do
while (/bin/egrep -i -A 5 'err:|warning:|error:|command not found|No such file or directory' /u00/app/oracle/oracle_software_movement.log);
do
   read -p " ERROR Found in output logfile !! Please verify the /u00/app/oracle/oracle_software_movement.log before proceed . Do you want to proceed (y/n) :" PROCEED
    case $PROCEED in
      n|N) echo -e " \e[1;91m ERROR Found in output logfile !! Oracle Database Software Movement Failed !! Oracle Database Software installation & Database(CDB with PDB) Creation Cancelled !!!!";tput sgr0
           echo -e "\n\n"
           exit -1;;
      y|Y) echo -e " \033[0;100m \033[1;97m Now Proceeding with Oracle Database Software installation ............ ";tput sgr0
           echo -e "\n\n"
           break 3;;
      *) echo -e " \e[1;91m Response not valid !!!!";tput sgr0
          echo -e "\n\n";;
    esac
done

echo -e " \033[0;100m \033[1;97m Please verify the /u00/app/oracle/oracle_software_movement.log before proceed . .......... ";tput sgr0
echo -e "\n\n"
echo -e "\033[0;100m \033[1;97m";read -p "Do you want to proceed (y/n) : " PROCEED;tput sgr0

case $PROCEED in
      n|N) echo -e " \e[1;91m Oracle Database Software Extract Failed !! Database(CDB with PDB) Creation Cancelled !!!! ";tput sgr0
           echo -e "\n\n"
           exit -1;;
      y|Y) echo -e " \033[0;100m \033[1;97m Now Proceeding with changing Oracle file permission of Oracle Databawe Home ................ ";tput sgr0
           echo -e "\n\n"
           break;;
      *) echo -e " \e[1;91m Response not valid !!!! ";tput sgr0
         echo -e "\n\n";;
    esac
done

###################################################################################################################################################################

#!THIS BLOCK WILL CHANGE THE oracle file Permission on Oracle Database Home

chmod 755 -R /u00/app/oracle/product/12.1.0/db_1
echo -e "\e[1;92m ####### Oracle Software has been extracted and permission changed: `date`......................... ";tput sgr0
echo -e "\n\n\n\n"
else
echo -e  "\e[1;91m Oracle folder movement failed: `date`...........................................  ";tput sgr0
echo -e "\n\n\n\n"
exit -1
fi
else
echo -e "\e[1;91m Oracle software extraction failed: `date`.................   ";tput sgr0
echo -e "\n\n\n\n"
exit -1
fi
echo -e " ##########################################################################################################################################  "
echo -e "\n\n\n\n"

################################################################################################################################################################

#!THIS BLOCK WILL ATTACH THE ORACLE DATABASE CLONE FOR DATABASE INSTALLATION

echo -e "  \033[0;100m \033[1;97m ###### Oracle database software installation started: `date`..................... ";tput sgr0
echo -e "\n\n\n\n"

/u00/app/oracle/product/12.1.0/db_1/perl/bin/perl /u00/app/oracle/product/12.1.0/db_1/clone/bin/clone.pl  -silent ORACLE_BASE=/u00/app/oracle ORACLE_HOME=/u00/app/oracle/product/12.1.0/db_1 ORACLE_HOME_NAME=OraDB12Home1 INVENTORY_LOCATION=/u00/app/oraInventory > /u00/app/oracle/oracle_software_installation.log 2>&1
retcode12=${?}
if [[ ${retcode12} -eq 0 ]]; then

while true
do
while (/bin/egrep -i -A 5 'err:|ora-|warning:|error:|command not found|No such file or directory' /u00/app/oracle/oracle_software_installation.log);
do
   read -p " ERROR Found in output logfile !! Please verify the /u00/app/oracle/oracle_software_installation.log before proceed . Do you want to proceed (y/n) :" PROCEED
    case $PROCEED in
      n|N) echo -e " \e[1;91m ERROR Found in output logfile !! Oracle Database Software installation Failed !! Database(CDB with PDB) Creation Cancelled !!!! ";tput sgr0
           echo -e "\n\n"
           exit -1;;
      y|Y) echo -e " \033[0;100m \033[1;97m Now Proceeding with root.sh script execution of Oracle Database Software installation............... ";tput sgr0
           echo -e "\n\n"
           break 3;;
      *) echo -e " \e[1;91m Response not valid !!!!!!! ";tput sgr0
         echo -e "\n\n";;
    esac
done

echo -e " \033[0;100m \033[1;97m Please verify the /u00/app/oracle/oracle_software_installation.log before proceed . ................. ";tput sgr0
echo -e "\n\n"
echo -e "\033[0;100m \033[1;97m";read -p "Do you want to proceed (y/n) : " PROCEED;tput sgr0

case $PROCEED in
      n|N) echo -e " \e[1;91m Oracle Database Software Extract Failed !! Database(CDB with PDB) Creation Cancelled !!!!!!!";tput sgr0
           echo -e "\n\n"
           exit -1;;
      y|Y) echo -e " \033[0;100m \033[1;97m Now Proceeding with root.sh script execution of Oracle Database Software installation.......... ";tput sgr0
           echo -e "\n\n"
           break;;
      *) echo -e " \e[1;91m Response not valid !!!!!!!! ";tput sgr0
         echo -e "\n\n";;
    esac
done

###################################################################################################################################################################

#!THIS BLOCK WILL EXECUTE THE ROOT.SH SCRIT AS A POST INSTALLATION STEP OF ORACLE DATABASE SOFTWARE INSTALLATION

echo -e "  \033[0;100m \033[1;97m ######## Now Executing root.sh script for Oracle Database Software installation started at: `date`......... ";tput sgr0
echo -e "\n\n"
sudo /u00/app/oracle/product/12.1.0/db_1/root.sh > /u00/app/oracle/oracle_software_root_sh.log 2>&1
retcode13=${?}
if [[ ${retcode13} -eq 0 ]]; then

while true
do
while (/bin/egrep -i -A 5 'err:|ora-|warning:|error:|command not found|No such file or directory' /u00/app/oracle/oracle_software_root_sh.log);
do
   read -p " ERROR Found in output logfile !! Please verify the /u00/app/oracle/oracle_software_root_sh.log before proceed . Do you want to proceed (y/n) :" PROCEED
    case $PROCEED in
      n|N) echo -e " \e[1;91m ERROR Found in output logfile !! root.sh for Oracle Database Software installation Failed !! Oracle Database(CDB with PDB) Creation Cancelled !!!! ";tput sgr0
           echo -e "\n\n"
           exit -1;;
      y|Y) echo -e " \033[0;100m \033[1;97m Now Proceeding with changing group owner of Oracle file ............... ";tput sgr0
           echo -e "\n\n"
           break 3;;
      *) echo -e " \e[1;91m Response not valid !!!! ";tput sgr0
         echo -e "\n\n";;
    esac
done

echo -e " \033[0;100m \033[1;97m Please verify the /u00/app/oracle/oracle_software_root_sh.log before proceed . .................. ";tput sgr0
echo -e "\n\n"

echo -e "\033[0;100m \033[1;97m";read -p "Do you want to proceed (y/n) : " PROCEED;tput sgr0

case $PROCEED in
      n|N) echo -e " \e[1;91m root.sh for Oracle Database Software installation Failed !! Oracle Database(CDB with PDB) Creation Cancelled !!!!!!! ";tput sgr0
           echo -e "\n\n"
           exit -1;;
      y|Y) echo -e " \033[0;100m \033[1;97m Now Proceeding with changing group owner of Oracle file .................... ";tput sgr0
           echo -e "\n\n"
           break;;
      *) echo -e " \e[1;91m Response not valid !!!!!!!!!!! ";tput sgr0
         echo -e "\n\n";;
    esac
done

echo -e "\e[1;92m ####### root.sh script for Oracle Database Software installation executed succesfully at: `date`............  ";tput sgr0
echo -e "\n\n\n\n"
echo -e "\e[1;92m ####### Oracle database software installation was Succesful: `date`........................  ";tput sgr0
echo -e "\n\n\n\n"
else
echo -e "\e[1;91m root.sh script execution failed at: `date`.....................................  ";tput sgr0
echo -e "\n\n\n\n"
exit -1
fi
else
echo -e  "\e[1;91m Oracle database software installation failed: `date`.............................   ";tput sgr0
echo -e "\n\n\n\n"
exit -1
fi

echo -e " #########################################################################################################################################  "
echo -e "\n\n"

################################################################################################################################################################

#! THIS BLOCK WILL CHANGE THE GROUP OWNERSHIP & PERMISSSION OF Oracle file ON RDBMS HOME

echo -e  " \033[0;100m \033[1;97m ##### Change the GROUP OWNERSHIP & PERMISSION for Oracle file ON RDBMS HOME: `date`...................... ";tput sgr0
echo -e "\n\n\n\n"

sudo chgrp asmadmin /u00/app/oracle/product/12.1.0/db_1/bin/oracle > /u00/app/oracle/change_oracle_file_group_owner.log 2>&1
retcode14=${?}

if [[ ${retcode14} -eq 0 ]]; then


while true
do
while (/bin/egrep -i -A 5 'err:|warning:|error:|command not found|No such file or directory' /u00/app/oracle/change_oracle_file_group_owner.log);
do
   read -p " ERROR Found in output logfile !! Please verify the /u00/app/oracle/change_oracle_file_group_owner.log before proceed . Do you want to proceed (y/n) :" PROCEED
    case $PROCEED in
      n|N) echo -e " \e[1;91m ERROR Found in output logfile !! Changing group owner of Oracle file Failed !! Oracle Database(CDB with PDB) Creation Cancelled !!!! ";tput sgr0
           echo -e "\n\n"
           exit -1;;
      y|Y) echo -e " \033[0;100m \033[1;97m Now Proceeding with Changing Permission of Oracle file ................  ";tput sgr0
           echo -e "\n\n"
           break 3;;
      *) echo -e " \e[1;91m Response not valid !!!!!!!!!! ";tput sgr0
         echo -e "\n\n";;
    esac
done

echo -e " \033[0;100m \033[1;97m Please verify the /u00/app/oracle/change_oracle_file_group_owner.log before proceed . ............ ";tput sgr0
echo -e "\n\n"
echo -e "\033[0;100m \033[1;97m";read -p "Do you want to proceed (y/n) : " PROCEED;tput sgr0

case $PROCEED in
      n|N) echo -e " \e[1;91m Changing group owner of Oracle file Failed !! Oracle Database(CDB with PDB) Creation Cancelled !!!!!!!! ";tput sgr0
           echo -e "\n\n"
           exit -1;;
      y|Y) echo -e " \033[0;100m \033[1;97m Now Proceeding with Changing Permission of Oracle file ......... ";tput sgr0
           echo -e "\n\n"
           break;;
      *) echo -e " \e[1;91m Response not valid !!!!!!!!!! ";tput sgr0
         echo -e "\n\n";;
    esac
done

###############################################################################################################################################################

#! THIS BLOCK WILL CHANGE PERMISSION OF Oracle file on RDBMS HOME

chmod 6751 /u00/app/oracle/product/12.1.0/db_1/bin/oracle > /u00/app/oracle/change_oracle_file_permission.log 2>&1
retcode15=${?}
if [[ ${retcode15} -eq 0 ]]; then


while true
do
while (/bin/egrep -i -A 5 'err:|warning:|error:|command not found|No such file or directory' /u00/app/oracle/change_oracle_file_permission.log);
do
   read -p " ERROR Found in output logfile !! Please verify the /u00/app/oracle/change_oracle_file_permission.log before proceed . Do you want to proceed (y/n) :" PROCEED
    case $PROCEED in
      n|N) echo -e " \e[1;91m ERROR Found in output logfile !! Changing Permission of Oracle file Failed !! Database(CDB with PDB) Creation Cancelled !!!! ";tput sgr0
           echo -e "\n\n"
           exit -1;;
      y|Y) echo -e " \033[0;100m \033[1;97m Now Proceeding with Oracle Database Creation .................. ";tput sgr0
           echo -e "\n\n"
           break 3;;
      *) echo -e " \e[1;91m Response not valid !!!!!!!!! ";tput sgr0
         echo -e "\n\n";;
    esac
done

echo -e " \033[0;100m \033[1;97m Please verify the /u00/app/oracle/change_oracle_file_permission.log before proceed . ............... ";tput sgr0
echo -e "\n\n"
echo -e "\033[0;100m \033[1;97m";read -p "Do you want to proceed (y/n) : " PROCEED;tput sgr0

case $PROCEED in
      n|N) echo -e " \e[1;91m Changing Permission of Oracle file Failed !! Database(CDB with PDB) Creation Cancelled !!!!";tput sgr0
           echo -e "\n\n"
           exit -1;;
      y|Y) echo -e " \033[0;100m \033[1;97m Now Proceeding with Oracle Database Creation ............................. ";tput sgr0
           echo -e "\n\n"
           break;;
      *) echo -e " \e[1;91m Response not valid !!!!!!!!!!!! ";tput sgr0
         echo -e "\n\n";;
    esac
done

echo -e "\e[1;92m ####### GROUP OWNERSHIP & PERMISSION CHANGE OF Oracle file has been succesful at: `date`............................   ";tput sgr0
echo -e "\n\n"
else
echo -e "\e[1;91m ###### PERMISSION CHANGE FOR Oracle file has been failed at: `date`...........................................   ";tput sgr0
echo -e "\n\n"
exit -1
fi
else
echo -e "\e[1;91m OWNERSHIP CHANGE FOR Oracle file has been failed at: `date`...................................................    ";tput sgr0
echo -e "\n\n"
exit -1
fi
echo -e " #############################################################################################################################################  "
echo -e "\n\n"

#################################################################################################################################################################

#! THIS BLOCK WILL CREAYE CDB WITH PLUGGABLE DATABASE ON 12C RDBMS HOME

echo -e  "   \033[0;100m \033[1;97m ######## Now creating CDB with Pluggable database: `date`............................  ";tput sgr0
echo -e "\n\n"
echo $TEMPLATE

/u00/app/oracle/product/12.1.0/db_1/bin/dbca -silent -createDatabase -templateName $TEMPLATE -gdbName $GLOBAL_CDB_NAME -sid $CDB_SID -createAsContainerDatabase true -numberOfPDBs 1 -pdbName $PDBNAME -pdbAdminPassword fRe5pu7ugubudR -sysPassword fRe5pu7ugubudR -systemPassword fRe5pu7ugubudR -olsConfiguration true -storageType ASM -asmsnmpPassword ta5uSEswacheSW -diskGroupName "ORADATA" -recoveryGroupName "ORARECO" -listeners LISTENER  -automaticMemoryManagement true > /u00/app/oracle/cdb_with_pdb_creation.log 2>&1
retcode16=${?}
if [[ ${retcode16} -eq 0 ]]; then

while true
do
while (/bin/egrep -i -A 5 'err:|ora-|warning:|error:|command not found|No such file or directory' /u00/app/oracle/cdb_with_pdb_creation.log);
do
   read -p " ERROR Found in output logfile !! Please verify the /u00/app/oracle/cdb_with_pdb_creation.log before proceed . Do you want to proceed (y/n) :" PROCEED
    case $PROCEED in
      n|N) echo -e " \e[1;91m ERROR Found in output logfile !! Oracle Database(CDB with PDB) Creation Failed !!!!!!!!  ";tput sgr0
           echo -e "\n\n"
           exit -1;;
      y|Y) echo -e " \033[0;100m \033[1;97m Oracle Database(CDB with PDB) Creation Successfully completed !!!!!!! ";tput sgr0
           echo -e "\n\n"
           break;;
      *) echo -e " \e[1;91m Response not valid !!!!!!! ";tput sgr0
         echo -e "\n\n"
           break 3;;
      *) echo -e " \e[1;91m Response not valid !!!!!! "
         echo -e "\n\n"
          tput sgr0;;
    esac
done

echo -e " \033[0;100m \033[1;97m Please verify the /u00/app/oracle/cdb_with_pdb_creation.log before proceed . ....... ";tput sgr0
echo -e "\n\n"
echo -e "\033[0;100m \033[1;97m";read -p "Do you want to proceed (y/n) : " PROCEED;tput sgr0

case $PROCEED in
      n|N) echo -e " \e[1;91m Oracle Database(CDB with PDB) Creation Failed !!!!!!!! ";tput sgr0
           echo -e "\n\n"
           exit -1;;
      y|Y) echo -e " \033[0;100m \033[1;97m Oracle Database(CDB with PDB) Creation Successfully completed !!!!!!!!! ";tput sgr0
           echo -e "\n\n"
           break;;
      *) echo -e " \e[1;91m Response not valid !!!!!!! ";tput sgr0
         echo -e "\n\n";;
    esac
done

echo -e "\e[1;92m ####### Created CDB with PDB succesfully: `date`.............................................";tput sgr0
echo -e "\n\n"
else
echo -e "\e[1;91m CDB with PDB creation failed: `date`.........................................................";tput sgr0
echo -e "\n\n\n\n"
exit -1
fi
echo -e " ####################################################################################################################################################"
echo -e "\n\n"

###############################################################################################################################################################

#!THIS BLOCK WILL LOGIN TO CDB DATABASE AND CREATE STARTUP TRIGGER TO OPEN PDB EVEY RESTART

echo -e  "  \033[0;100m \033[1;97m ####### Login to CDB Database and create the startup trigger to open the PDBs : `date`....................  ";tput sgr0
echo -e "\n\n"
export ORACLE_SID=$CDB_SID
export ORACLE_HOME=/u00/app/oracle/product/12.1.0/db_1
export PATH=$PATH:$ORACLE_HOME/bin:.

sqlplus  / as sysdba<<END
set echo on
set feedback on
set serveroutput on
spool /u00/app/oracle/product/12.1.0/db_1/tesco/dbca/scripts/open_pdb.log
select name,open_mode,database_role from v\$database;

create or replace trigger Sys.After_Startup after startup on database
begin
   execute immediate 'alter pluggable database all open';
end After_Startup;
/
END
spool off
echo -e "\e[1;92m ####### Startup trigger created succesfully : `date`.......................................................    ";tput sgr0
echo -e "\n\n"
echo -e " ########################################################################################################################################### "
echo -e "\n\n"

###############################################################################################################################################################

#!THIS BLOCK WILL OPEN PLUGGABLE DATABSE AND LIST THE INSTALLED COMPONENTS

echo -e  "   \033[0;100m \033[1;97m  ####### Login to PDB, open the PDB and verify the component status : `date`........................... ";tput sgr0
echo -e "\n\n\n\n"

sqlplus  / as sysdba<<END
set echo on
set feedback on
set serveroutput on
select name,open_mode,database_role from v\$database;
alter session set container=$PDBNAME;
select name,open_mode from v\$pdbs;
alter pluggable database $PDBNAME open;
alter session set container=$PDBNAME;
set pages 4000 lines 235
col COMP_ID for a25
col COMP_NAME for a75
col VERSION for a25
col STATUS for a15
select COMP_ID,COMP_NAME,VERSION,STATUS from dba_registry;
spool off
END

echo -e "\e[1;92m ####### All Pluggable Databases Opened successfully and verified the component status: `date`..............................";tput sgr0
echo -e "\n\n"
echo -e " ################################################################################################################################################  "
echo -e "\n\n\n\n"

###############################################################################################################################################################

#!THIS BLOCK WILL EXECUTE THE POST DATABASE CREATION SCRIPT

#!/bin/bash
echo -e "\e[1;92m ####### Please add database entry in the /etc/oratab:<db_name> :/u01/app/oracle/product/12.1.0/db_1:Y ................... ";tput sgr0
echo -e "\n\n\n\n"

export ORACLE_SID=$CDB_SID
export PDBNAME=$PDBNAME

/u00/app/oracle/product/12.1.0/db_1/bin/sqlplus / as sysdba<<END

SET VERIFY OFF
set echo on
spool /u00/app/oracle/PostDBScripts_output.log append
@/u00/app/oracle/product/12.1.0/db_1/tesco/dbca/scripts/disable_space_alerting.sql;
@/u00/app/oracle/product/12.1.0/db_1/tesco/dbca/scripts/disable_xmldb.sql;
@/u00/app/oracle/product/12.1.0/db_1/tesco/dbca/scripts/logging.sql;
@/u00/app/oracle/product/12.1.0/db_1/tesco/dbca/scripts/awr_settings.sql;
@/u00/app/oracle/product/12.1.0/db_1/tesco/dbca/scripts/online_log_dest.sql;
@/u00/app/oracle/product/12.1.0/db_1/tesco/dbca/scripts/tesco_pwd_verify_fcn.sql;
@/u00/app/oracle/product/12.1.0/db_1/tesco/dbca/scripts/randomize_all_passwords.sql;
@/u00/app/oracle/product/12.1.0/db_1/tesco/dbca/scripts/audit_cleanup_cdb.sql;
@/u00/app/oracle/product/12.1.0/db_1/tesco/dbca/scripts/instance_caging.sql;
@/u00/app/oracle/product/12.1.0/db_1/tesco/dbca/scripts/lock_system.sql;
@/u00/app/oracle/product/12.1.0/db_1/tesco/dbca/scripts/trigger_to_open_all_pdbs.sql
spool off
exit;
END

/u00/app/oracle/product/12.1.0/db_1/bin/sqlplus / as sysdba<<END

SET VERIFY OFF
set echo on
spool /u00/app/oracle/PostDBScripts_output.log append
alter session set container=$PDBNAME;
show con_name
@/u00/app/oracle/product/12.1.0/db_1/tesco/dbca/scripts/disable_space_alerting.sql;
@/u00/app/oracle/product/12.1.0/db_1/tesco/dbca/scripts/disable_xmldb.sql;
@/u00/app/oracle/product/12.1.0/db_1/tesco/dbca/scripts/online_log_dest.sql;
@/u00/app/oracle/product/12.1.0/db_1/tesco/dbca/scripts/tesco_pwd_verify_fcn.sql;
@/u00/app/oracle/product/12.1.0/db_1/tesco/dbca/scripts/tesco_user_roles.sql;
@/u00/app/oracle/product/12.1.0/db_1/tesco/dbca/scripts/randomize_all_passwords.sql;
@/u00/app/oracle/product/12.1.0/db_1/tesco/dbca/scripts/tesco_create_profile.sql;
@/u00/app/oracle/product/12.1.0/db_1/tesco/dbca/scripts/audit_cleanup_pdb.sql;
@/u00/app/oracle/product/12.1.0/db_1/tesco/dbca/scripts/lock_system.sql;
spool off
exit;
END


retcode17=${?}
if [[ ${retcode17} -eq 0 ]]; then

while (/bin/egrep -i -A 5 'err:|ora-|warning:|error:|command not found|No such file or directory' /u00/app/oracle/PostDBScripts_output.log);
do
   echo -e " \e[1;91m ERROR Found in output logfile !! Please verify the /u00/app/oracle/PostDBScripts_output.log. !!!!!!!!  ";tput sgr0
   exit -1
done
else
echo -e " \e[1;91m ERROR Found in output logfile !! Please verify the /u00/app/oracle/PostDBScripts_output.log. !!!!!!!!  ";tput
echo -e "\n\n\n\n"
exit -1
fi

#!THIS COMPLTE THE ORACLE 12c GRID INFRASTRUCTURE CONFIGURATION & CDB WITH PDB CREATION

#!THIS COMPLTE THE ORACLE 12c GRID INFRASTRUCTURE CONFIGURATION & CDB WITH PDB CREATION


